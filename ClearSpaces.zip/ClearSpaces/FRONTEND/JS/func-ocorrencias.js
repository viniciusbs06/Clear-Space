/* ==========================================================================
   CLEAR SPACE - OCORRÊNCIAS DO FUNCIONÁRIO (func-ocorrencias.html)
   Depende de: common.js
========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
    carregarHistoricoOcorrencias();
});

function getNomeUsuarioAtual() {
    const usuario = getUsuarioLogado();
    return usuario && usuario.nome ? usuario.nome : "Funcionário Operacional";
}

function salvarOcorrencia() {
    const gravidade = document.getElementById("sel-ocorrencia-gravidade").value;
    const mensagem = document.getElementById("txt-ocorrencia-mensagem").value.trim();

    if (!mensagem) {
        showToast("Escreva uma mensagem detalhando o ocorrido!", "error");
        return;
    }

    const agora = new Date();
    const dataFormatada = agora.toLocaleDateString('pt-BR') + " " + agora.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

    const ocorrenciasLocais = JSON.parse(localStorage.getItem("SGC_ocorrencias")) || [];

    const novaOcorrencia = {
        id: Date.now(),
        remetente: getNomeUsuarioAtual(),
        gravidade: gravidade,
        mensagem: mensagem,
        data: dataFormatada,
        status: "pendente",
        encarregado: ""
    };

    ocorrenciasLocais.push(novaOcorrencia);
    localStorage.setItem("SGC_ocorrencias", JSON.stringify(ocorrenciasLocais));

    showToast("Mensagem enviada com sucesso!");
    document.getElementById("txt-ocorrencia-mensagem").value = "";

    carregarHistoricoOcorrencias();
}

function carregarHistoricoOcorrencias() {
    const container = document.getElementById("historico-ocorrencias-container");
    if (!container) return;

    const ocorrenciasLocais = JSON.parse(localStorage.getItem("SGC_ocorrencias")) || [];
    const meuNome = getNomeUsuarioAtual();
    const minhasOcorrencias = ocorrenciasLocais.filter(o => o.remetente === meuNome);

    if (minhasOcorrencias.length === 0) {
        container.innerHTML = `<p class="no-alerts">Você ainda não enviou nenhuma mensagem hoje.</p>`;
        return;
    }

    container.innerHTML = minhasOcorrencias.slice().reverse().map(oc => `
        <div class="msg-historico-card">
            <div class="msg-header-line">
                <span class="badge-gravidade badge-${oc.gravidade}">${oc.gravidade}</span>
                <span class="msg-time-stamp">${oc.data}</span>
            </div>
            <div class="msg-body-text">${oc.mensagem}</div>
            ${oc.status === 'resolvido'
                ? `<div class="status-resolvido-box">✓ Designado para: ${oc.encarregado}</div>`
                : `<div class="status-resolvido-box" style="background:#fff3cd; color:#856404; border-color:#ffeeba;">⏳ Aguardando leitura do Gestor</div>`
            }
        </div>
    `).join('');
}

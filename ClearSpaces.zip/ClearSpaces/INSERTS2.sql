use clearSpaces;

select * from funcionario;
select * from periodo;
select * from ambiente;

INSERT INTO funcionario (nome, cpf, matricula, senha) 
VALUES ('gestor', '12345678901', '1021', '123456');
INSERT INTO funcionario (funcao, matricula, nome, periodo_id, cpf, senha) 
VALUES ('asg', 'ASG12345', 'João Silva', 1, '12345678900', 'senha123');
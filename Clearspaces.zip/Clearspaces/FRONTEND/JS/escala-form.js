let editandoId = null;
let cacheFuncionarios = JSON.parse(localStorage.getItem("SGC_cache_funcionarios")) || [];

document.addEventListener("DOMContentLoaded", async () => {
    await carregarSeletoresEscala();

    const editId = localStorage.getItem('editEscalaId');
    if (editId) {
        await prepararEdicaoEscala(editId);
    }
});

async function carregarSeletoresEscala() {
    try {
        const resFunc = await fetch(`${API_URL}/funcionarios/listar`);
        if (resFunc.ok) {
            cacheFuncionarios = await resFunc.json();
            localStorage.setItem("SGC_cache_funcionarios", JSON.stringify(cacheFuncionarios));
        }
    } catch (err) {}

    const selEscalaFunc = document.getElementById("sel-escala-func");
    if (selEscalaFunc) {
        selEscalaFunc.innerHTML = cacheFuncionarios.map(f => `<option value="${f.id}">${f.nome} (${f.funcao ? f.funcao.toUpperCase() : 'ASG'})</option>`).join('');
    }

    let locaisLista = JSON.parse(localStorage.getItem("SGC_locais_fallback")) || [];
    try {
        const resLocais = await fetch(`${API_URL}/ambientes`);
        if (resLocais.ok) {
            locaisLista = await resLocais.json();
            localStorage.setItem("SGC_locais_fallback", JSON.stringify(locaisLista));
        }
    } catch (err) {}

    const selEscalaLocal = document.getElementById("sel-escala-local");
    if (selEscalaLocal) {
        selEscalaLocal.innerHTML = locaisLista.length > 0
            ? locaisLista.map(l => `<option value="${l.id}">${l.nome}</option>`).join('')
            : `<option value="">Nenhum ambiente mapeado</option>`;
    }

    const selEscalaTarefa = document.getElementById("sel-escala-tarefa");
    if (selEscalaTarefa) {
        selEscalaTarefa.innerHTML = `
            <option value="1">Limpeza de Piso / Lavagem</option>
            <option value="2">Recolhimento de Resíduos</option>
            <option value="3">Reposição de Insumos</option>
        `;

        try {
            const resTarefas = await fetch(`${API_URL}/tarefas`);
            if (resTarefas.ok) {
                const tarefas = await resTarefas.json();
                if (tarefas && tarefas.length > 0) {
                    selEscalaTarefa.innerHTML = tarefas.map(t => `<option value="${t.id}">${t.descricao}</option>`).join('');
                }
            }
        } catch (err) {}
    }
}

async function prepararEdicaoEscala(id) {
    let atribuicoes = JSON.parse(localStorage.getItem("SGC_escalas_fallback")) || [];
    try {
        const res = await fetch(`${API_URL}/atribuicoes`);
        if (res.ok) {
            const dadosApi = await res.json();
            if (dadosApi && dadosApi.length > 0) atribuicoes = dadosApi;
        }
    } catch (err) {}

    const cron = atribuicoes.find(c => c.id == id);
    if (!cron) return;

    editandoId = cron.id;

    if (document.getElementById("sel-escala-func")) document.getElementById("sel-escala-func").value = cron.funcionario ? cron.funcionario.id : "";
    if (document.getElementById("sel-escala-local")) document.getElementById("sel-escala-local").value = cron.ambiente ? cron.ambiente.id : "";
    if (document.getElementById("sel-escala-tarefa")) document.getElementById("sel-escala-tarefa").value = cron.tarefa ? cron.tarefa.id : "";

    const diaSelect = document.getElementById("sel-escala-dia");
    if (diaSelect && cron.diaSemana) {
        const opcaoDia = Array.from(diaSelect.options).find(opt => opt.value.toLowerCase().includes(cron.diaSemana.toLowerCase()));
        if (opcaoDia) diaSelect.value = opcaoDia.value;
    }

    document.getElementById("time-escala-inicio").value = cron.horarioInicio ? cron.horarioInicio.substring(0, 5) : "";
    document.getElementById("time-escala-fim").value = cron.horarioFim ? cron.horarioFim.substring(0, 5) : "";

    document.querySelector('h1').innerText = "Editar Horário da Grade";
    const btnSubmit = document.querySelector("button[type='submit']");
    if (btnSubmit) btnSubmit.innerText = "Atualizar Grade";
}

async function salvarEscala() {
    const funcSelect = document.getElementById("sel-escala-func");
    const localSelect = document.getElementById("sel-escala-local");
    const tarefaSelect = document.getElementById("sel-escala-tarefa");
    const diaSelect = document.getElementById("sel-escala-dia");
    const inicioInput = document.getElementById("time-escala-inicio");
    const fimInput = document.getElementById("time-escala-fim");

    if (!funcSelect || !localSelect || !inicioInput || !fimInput) {
        showToast("Erro ao ler os selects de escala.", "error");
        return;
    }

    const diaLimpo = diaSelect && diaSelect.value ? diaSelect.value : "segunda";

    const dto = {
        funcionarioId: parseInt(funcSelect.value),
        ambienteId: parseInt(localSelect.value),
        tarefaId: tarefaSelect ? parseInt(tarefaSelect.value) : 1,
        diaSemana: diaLimpo,
        horarioInicio: inicioInput.value + ":00",
        horarioFim: fimInput.value + ":00"
    };

    if (!inicioInput.value || !fimInput.value || isNaN(dto.funcionarioId) || isNaN(dto.ambienteId)) {
        showToast("Preencha todos os campos da escala!", "error");
        return;
    }

    try {
        let url = `${API_URL}/atribuicoes`;
        let method = "POST";
        if (editandoId) {
            url += `/${editandoId}`;
            method = "PUT";
        }

        const res = await fetch(url, {
            method: method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(dto)
        });

        if (res.ok) {
            showToast("Escala salva!");
            localStorage.removeItem('editEscalaId');
            window.location.href = 'escala-lista.html';
            return;
        }
    } catch (error) {}

    let bancoEscalas = JSON.parse(localStorage.getItem("SGC_escalas_fallback")) || [];
    const funcCache = cacheFuncionarios.find(f => f.id === dto.funcionarioId) || { nome: funcSelect.options[funcSelect.selectedIndex].text };
    let locaisLista = JSON.parse(localStorage.getItem("SGC_locais_fallback")) || [];
    const ambCache = locaisLista.find(a => a.id === dto.ambienteId) || { nome: localSelect.options[localSelect.selectedIndex].text };
    const nomeTarefa = tarefaSelect && tarefaSelect.options[tarefaSelect.selectedIndex] ? tarefaSelect.options[tarefaSelect.selectedIndex].text : "Limpeza Padrão";

    const novaEscala = {
        id: editandoId || Date.now(),
        funcionario: funcCache,
        ambiente: ambCache,
        tarefa: { id: dto.tarefaId, descricao: nomeTarefa },
        diaSemana: diaLimpo,
        horarioInicio: dto.horarioInicio,
        horarioFim: dto.horarioFim
    };

    if (!editandoId) {
        bancoEscalas.push(novaEscala);
        showToast("Escala salva localmente!");
    } else {
        bancoEscalas = bancoEscalas.map(e => e.id === editandoId ? novaEscala : e);
        showToast("Escala atualizada localmente!");
    }

    localStorage.setItem("SGC_escalas_fallback", JSON.stringify(bancoEscalas));
    localStorage.removeItem('editEscalaId');
    window.location.href = 'escala-lista.html';
}
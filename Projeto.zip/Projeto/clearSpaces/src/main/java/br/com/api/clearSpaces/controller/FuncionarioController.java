package br.com.api.clearSpaces.controller;

import br.com.api.clearSpaces.dto.FuncionarioDTO;
import br.com.api.clearSpaces.entity.Funcionario;
import br.com.api.clearSpaces.service.FuncionarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/funcionarios")
@CrossOrigin("*")
public class FuncionarioController {

    @Autowired
    private FuncionarioService funcionarioService;

    @PostMapping
    public void criar(@RequestBody FuncionarioDTO dto) {
        funcionarioService.criar(dto);
    }

    @GetMapping
    public List<Funcionario> listar() {
        return funcionarioService.ler();
    }

    @PutMapping("/{id}")
    public void atualizar(@PathVariable Long id, @RequestBody FuncionarioDTO dto) {
        funcionarioService.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id) {
        funcionarioService.deletar(id);
    }
}
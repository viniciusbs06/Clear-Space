document.addEventListener("DOMContentLoaded", async () => {
    const editId = localStorage.getItem('editFuncionarioId');
    const inputNome = document.getElementById('func-nome');
    if (!editId || !inputNome) return;

    try {
        const res = await fetch(`${API_URL}/funcionarios/listar`);
        if (res.ok) {
            const lista = await res.json();
            const func = lista.find(f => f.id == editId);
            if (func) {
                document.getElementById('func-nome').value = func.nome || '';
                document.getElementById('func-cpf').value = func.cpf || '';
                document.getElementById('func-cargo').value = func.funcao ? func.funcao.toLowerCase() : 'asg';
                document.getElementById('func-periodo').value = func.periodo ? func.periodo.id : 1;

                const inputSenha = document.getElementById('func-senha');
                if (inputSenha) {
                    inputSenha.required = false;
                    inputSenha.placeholder = "Deixe em branco para manter a senha atual";
                }

                document.querySelector('h1').innerText = "Editar Colaborador";
                const btnSubmit = document.querySelector("button[type='submit']");
                if (btnSubmit) btnSubmit.innerText = "Atualizar Colaborador no Banco";
            }
        }
    } catch (err) {
        console.error("Erro ao carregar colaborador para edição:", err);
    }
});

async function salvarColaborador() {
    const editId = localStorage.getItem('editFuncionarioId');
    const nome = document.getElementById('func-nome').value;
    const cpf = document.getElementById('func-cpf').value;
    const senha = document.getElementById('func-senha').value;
    const funcao = document.getElementById('func-cargo').value;
    const periodoId = document.getElementById('func-periodo').value;

    const funcionarioDTO = {
        nome: nome,
        cpf: cpf,
        senha: senha,
        funcao: funcao,
        periodoId: Number(periodoId)
    };

    const url = editId ? `${API_URL}/funcionarios/${editId}` : `${API_URL}/funcionarios/registrar`;
    const method = editId ? 'PUT' : 'POST';

    try {
        const response = await fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(funcionarioDTO)
        });

        if (response.ok) {
            alert(editId ? 'Colaborador atualizado com sucesso!' : 'Colaborador cadastrado com sucesso!');
            localStorage.removeItem('editFuncionarioId');
            window.location.href = 'equipe-lista.html';
        } else {
            const msgErro = await response.text();
            alert('Erro ao salvar colaborador: ' + (msgErro || 'Verifique os dados enviados.'));
        }
    } catch (error) {
        console.error('Erro de conexão:', error);
        alert('Erro ao conectar com o servidor Java.');
    }
}
package br.com.api.clearSpaces.controller;

import br.com.api.clearSpaces.dto.AmbienteDTO;
import br.com.api.clearSpaces.entity.Ambiente;
import br.com.api.clearSpaces.service.AmbienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/ambientes")
public class AmbienteController {
    @Autowired
    private AmbienteService ambienteService;

    @PostMapping
    public void criar(@RequestBody AmbienteDTO dto) {
        ambienteService.criar(dto);
    }

    @GetMapping
    public List<Ambiente> listar() {
        List<Ambiente> lista = ambienteService.ler();
        return lista;
    }

    @PutMapping("/{id}")
    public void atualizar(@PathVariable Long id, @RequestBody AmbienteDTO dto) {
        ambienteService.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id) {
        ambienteService.deletar(id);
    }
}
package br.com.api.clearSpaces.repository;

import br.com.api.clearSpaces.entity.Ambiente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AmbienteRepository extends JpaRepository<Ambiente,Long> {
}

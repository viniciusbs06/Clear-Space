const API_URL = "http://localhost:8080";
let editandoId = null;
let diaSelecionado = "segunda";

// Base de dados unificada via LocalStorage para sincronizar o Funcionário e o Gestor em tempo real
let ocorrenciasLocais = JSON.parse(localStorage.getItem("SGC_ocorrencias")) || [
    {
        id: 1,
        remetente: "Carlos Alberto (ASG)",
        gravidade: "leve",
        mensagem: "Falta de papel toalha no banheiro do bloco B.",
        data: "15/06/2026 14:20",
        status: "pendente",
        encarregado: ""
    },
    {
        id: 2,
        remetente: "Maria Oliveira (Banheirista)",
        gravidade: "urgente",
        mensagem: "Vazamento contínuo na pia principal da doca 4.",
        data: "15/06/2026 16:05",
        status: "resolvido",
        encarregado: "Encarregado Marcos"
    }
];

// Lista de Funcionários em cache/local para rodar offline ou online
let cacheFuncionarios = JSON.parse(localStorage.getItem("SGC_cache_funcionarios")) || [
    { id: 1, nome: "Carlos Alberto", matricula: "1010", funcao: "asg" },
    { id: 2, nome: "Maria Oliveira", matricula: "2020", funcao: "banheirista" }
];

document.addEventListener("DOMContentLoaded", () => {
    configurarEventosInterface();
    carregarPainelGerente();
    carregarListaFuncionarios();
    carregarListaLocais();
    carregarListaEscalas();
    carregarSeletoresFormularios();
    carregarHistoricoOcorrencias();
    renderizarAlertasGestor();
});

function showToast(mensagem, tipo = "success") {
    const container = document.getElementById("toast-container") || criarToastContainer();
    const toast = document.createElement("div");
    toast.className = `toast toast-${tipo}`;
    toast.innerText = mensagem;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

function criarToastContainer() {
    const container = document.createElement("div");
    container.id = "toast-container";
    const appContainer = document.querySelector(".app-container") || document.body;
    appContainer.appendChild(container);
    return container;
}

function configurarEventosInterface() {
    // Agora aceita spans, buttons ou divs que estiverem dentro do menu de semanas
    document.querySelectorAll(".week-nav span, .week-nav button, .week-nav div").forEach(btn => {
        btn.addEventListener("click", (e) => {
            document.querySelectorAll(".week-nav span, .week-nav button, .week-nav div").forEach(b => b.classList.remove("active"));
            e.target.classList.add("active");
            
            const textoDia = e.target.innerText.toLowerCase();
            if (textoDia.includes("seg")) diaSelecionado = "segunda";
            else if (textoDia.includes("ter")) diaSelecionado = "terça";
            else if (textoDia.includes("qua")) diaSelecionado = "quarta";
            else if (textoDia.includes("qui")) diaSelecionado = "quinta";
            else if (textoDia.includes("sex")) diaSelecionado = "sexta";
            
            carregarListaEscalas();
        });
    });
}

/* ==========================================================================
   FLUXO DE OCORRÊNCIAS (FUNCIONÁRIO & GESTOR)
========================================================================== */

function salvarOcorrencia() {
    const gravidade = document.getElementById("sel-ocorrencia-gravidade").value;
    const mensagem = document.getElementById("txt-ocorrencia-mensagem").value.trim();
    const nomeRemetente = document.getElementById("login-usuario-nome") ? document.getElementById("login-usuario-nome").value : "Funcionário Operacional";

    if (!mensagem) {
        showToast("Escreva uma mensagem detalhando o ocorrido!", "error");
        return;
    }

    const agora = new Date();
    const dataFormatada = agora.toLocaleDateString('pt-BR') + " " + agora.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });

    const novaOcorrencia = {
        id: Date.now(),
        remetente: nomeRemetente,
        gravidade: gravidade,
        mensagem: mensagem,
        data: dataFormatada,
        status: "pendente",
        encarregado: ""
    };

    ocorrenciasLocais.push(novaOcorrencia);
    localStorage.setItem("SGC_ocorrencias", JSON.stringify(ocorrenciasLocais));

    showToast("Mensagem enviada com sucesso!");
    document.getElementById("txt-ocorrencia-mensagem").value = "";
    
    carregarHistoricoOcorrencias();
    renderizarAlertasGestor();
}

function carregarHistoricoOcorrencias() {
    const container = document.getElementById("historico-ocorrencias-container");
    if (!container) return;

    const meuNome = document.getElementById("login-usuario-nome") ? document.getElementById("login-usuario-nome").value : "Funcionário Operacional";
    const minhasOcorrencias = ocorrenciasLocais.filter(o => o.remetente === meuNome);

    if (minhasOcorrencias.length === 0) {
        container.innerHTML = `<p class="no-alerts">Você ainda não enviou nenhuma mensagem hoje.</p>`;
        return;
    }

    container.innerHTML = minhasOcorrencias.slice().reverse().map(oc => `
        <div class="msg-historico-card">
            <div class="msg-header-line">
                <span class="badge-gravidade badge-${oc.gravidade}">${oc.gravidade}</span>
                <span class="msg-time-stamp">${oc.data}</span>
            </div>
            <div class="msg-body-text">${oc.mensagem}</div>
            ${oc.status === 'resolvido' ? 
                `<div class="status-resolvido-box">✓ Designado para: ${oc.encarregado}</div>` 
                : `<div class="status-resolvido-box" style="background:#fff3cd; color:#856404; border-color:#ffeeba;">⏳ Aguardando leitura do Gestor</div>`
            }
        </div>
    `).join('');
}

function renderizarAlertasGestor() {
    const container = document.getElementById("painel-alertas-container");
    if (!container) return;

    const pendentes = ocorrenciasLocais.filter(oc => oc.status === "pendente");

    if (pendentes.length === 0) {
        container.innerHTML = `<p class="no-alerts">Nenhuma ocorrência ou solicitação pendente no momento.</p>`;
        return;
    }

    const optionsFuncionarios = cacheFuncionarios.length > 0 
        ? cacheFuncionarios.map(f => `<option value="${f.nome}">${f.nome} (${f.funcao ? f.funcao.toUpperCase() : 'ASG'})</option>`).join('')
        : `<option value="Equipe Geral">Equipe Operacional de Plantão</option>`;

    container.innerHTML = pendentes.slice().reverse().map(oc => `
        <div class="gestor-alerta-card border-${oc.gravidade}">
            <div class="msg-header-line">
                <span class="badge-gravidade badge-${oc.gravidade}">${oc.gravidade}</span>
                <span class="msg-time-stamp">${oc.data}</span>
            </div>
            <div class="alerta-meta-info">Enviado por: <strong>${oc.remetente}</strong></div>
            <div class="msg-body-text">"${oc.mensagem}"</div>
            
            <div class="designar-box">
                <label>Designar colaborador para solucionar:</label>
                <div class="designar-controls">
                    <select id="select-delegar-${oc.id}">
                        <option value="">Escolha quem vai resolver...</option>
                        ${optionsFuncionarios}
                    </select>
                    <button class="btn-designar-acao" onclick="delegarOcorrencia(${oc.id})">Designar</button>
                </div>
            </div>
        </div>
    `).join('');
}

function delegarOcorrencia(idOcorrencia) {
    const select = document.getElementById(`select-delegar-${idOcorrencia}`);
    
    if (!select || !select.value) {
        showToast("Por favor, selecione um funcionário antes de designar!", "error");
        return;
    }

    const funcionarioEscolhido = select.value;

    ocorrenciasLocais = ocorrenciasLocais.map(oc => {
        if (oc.id === idOcorrencia) {
            return { ...oc, status: "resolvido", encarregado: funcionarioEscolhido };
        }
        return oc;
    });

    localStorage.setItem("SGC_ocorrencias", JSON.stringify(ocorrenciasLocais));
    showToast(`Sucesso! Problema delegado para ${funcionarioEscolhido}.`);
    
    renderizarAlertasGestor();
    carregarHistoricoOcorrencias();
}


/* ==========================================================================
   POPULAR SELETORES DOS FORMULÁRIOS
========================================================================== */
async function carregarSeletoresFormularios() {
    const selPeriodo = document.getElementById("sel-func-periodo");
    if (selPeriodo) {
        selPeriodo.innerHTML = `
            <option value="1">MANHÃ (06:00 - 14:00)</option>
            <option value="2">TARDE (14:00 - 22:00)</option>
            <option value="3">NOITE (22:00 - 06:00)</option>
        `;
    }
    
    try {
        const resPeriodos = await fetch(`${API_URL}/periodos`);
        if(resPeriodos.ok) {
            const periodos = await resPeriodos.json();
            if (selPeriodo && periodos.length > 0) {
                selPeriodo.innerHTML = periodos.map(p => `<option value="${p.id}">${p.periodoEnum.toUpperCase()}</option>`).join('');
            }
        }
    } catch(e) {}

    try {
        const resFunc = await fetch(`${API_URL}/funcionarios`);
        if(resFunc.ok) {
            cacheFuncionarios = await resFunc.json();
            localStorage.setItem("SGC_cache_funcionarios", JSON.stringify(cacheFuncionarios));
        }
    } catch (err) {}

    const selEscalaFunc = document.getElementById("sel-escala-func");
    if (selEscalaFunc && cacheFuncionarios) {
        selEscalaFunc.innerHTML = cacheFuncionarios.map(f => `<option value="${f.id}">${f.nome} (${f.funcao ? f.funcao.toUpperCase() : 'ASG'})</option>`).join('');
    }

    renderizarAlertasGestor();

    const selEscalaLocal = document.getElementById("sel-escala-local");
    if (selEscalaLocal) {
        let locaisLista = JSON.parse(localStorage.getItem("SGC_locais_fallback")) || [];
        try {
            const resLocais = await fetch(`${API_URL}/ambientes`);
            if(resLocais.ok) {
                locaisLista = await resLocais.json();
                localStorage.setItem("SGC_locais_fallback", JSON.stringify(locaisLista));
            }
        } catch (err) {}

        if (locaisLista.length > 0) {
            selEscalaLocal.innerHTML = locaisLista.map(l => `<option value="${l.id}">${l.nome}</option>`).join('');
        } else {
            selEscalaLocal.innerHTML = `<option value="">Nenhum ambiente mapeado</option>`;
        }
    }

    const selEscalaTarefa = document.getElementById("sel-escala-tarefa");
    if (selEscalaTarefa) {
        selEscalaTarefa.innerHTML = `
            <option value="1">Limpeza de Piso / Lavagem</option>
            <option value="2">Recolhimento de Resíduos</option>
            <option value="3">Reposição de Insumos</option>
        `;
        
        try {
            const resTarefas = await fetch(`${API_URL}/tarefas`);
            if(resTarefas.ok) {
                const tarefas = await resTarefas.json();
                if (tarefas && tarefas.length > 0) {
                    selEscalaTarefa.innerHTML = tarefas.map(t => `<option value="${t.id}">${t.descricao}</option>`).join('');
                }
            }
        } catch (err) {
            console.log("Servidor offline ou sem tarefas: utilizando tarefas padrao.");
        }
    }
}

/* ==========================================================================
   PAINEL DO GERENTE (Contadores)
========================================================================== */
async function carregarPainelGerente() {
    let ambientes = JSON.parse(localStorage.getItem("SGC_locais_fallback")) || [];

    try {
        const resAmbientes = await fetch(`${API_URL}/ambientes`);
        if (resAmbientes.ok) {
            ambientes = await resAmbientes.json();
            localStorage.setItem("SGC_locais_fallback", JSON.stringify(ambientes));
        }
    } catch (error) {
        console.log("Modo offline: Atualizando painel com dados locais.");
    }

    // Filtra ignorando letras maiúsculas/minúsculas para evitar erros de digitação
    const limpos = ambientes.filter(a => a.statusAmbiente && a.statusAmbiente.toLowerCase() === 'limpo').length;
    const pendentes = ambientes.filter(a => a.statusAmbiente && (a.statusAmbiente.toLowerCase() === 'pendente' || a.statusAmbiente.toLowerCase() === 'pendente de limpeza')).length;
    const sujos = ambientes.filter(a => a.statusAmbiente && a.statusAmbiente.toLowerCase() === 'sujo').length;

    if (document.querySelector(".stat-item.blue h2")) document.querySelector(".stat-item.blue h2").innerText = limpos;
    if (document.querySelector(".stat-item.yellow h2")) document.querySelector(".stat-item.yellow h2").innerText = pendentes;
    if (document.querySelector(".stat-item.red-alert h2")) document.querySelector(".stat-item.red-alert h2").innerText = sujos;
}

/* ==========================================================================
   CRUD: COLABORADORES
========================================================================== */
async function carregarListaFuncionarios() {
    const container = document.getElementById("lista-funcionarios-container");
    if (!container) return;

    try {
        const res = await fetch(`${API_URL}/funcionarios`);
        if(res.ok) {
            cacheFuncionarios = await res.json();
            localStorage.setItem("SGC_cache_funcionarios", JSON.stringify(cacheFuncionarios));
        }
    } catch (error) {}

    if (!cacheFuncionarios || cacheFuncionarios.length === 0) {
        container.innerHTML = `<p class="no-alerts">Nenhum funcionário cadastrado.</p>`;
        return;
    }

    container.innerHTML = cacheFuncionarios.map(func => `
        <div class="crud-item-card">
            <div class="crud-icon-box">👤</div>
            <div class="crud-details">
                <h4>${func.nome}</h4>
                <p>Matrícula: ${func.matricula} | Função: ${func.funcao ? func.funcao.toUpperCase() : 'ASG'}</p>
            </div>
            <div class="crud-actions">
                <span onclick='prepararEdicaoFuncionario(${JSON.stringify(func)})'>✏️</span>
                <span onclick="deletarFuncionario(${func.id})">🗑️</span>
            </div>
        </div>
    `).join('');
}

async function salvarFuncionario() {
    const nome = document.getElementById("txt-func-nome").value.trim();
    const matricula = document.getElementById("txt-func-matricula").value.trim();
    const funcaoMapeada = document.getElementById("sel-func-funcao") ? document.getElementById("sel-func-funcao").value : "asg";
    const comboPeriodo = document.getElementById("sel-func-periodo");
    const periodoId = comboPeriodo && comboPeriodo.value ? parseInt(comboPeriodo.value) : 1;

    if (!nome || !matricula) {
        showToast("Insira o Nome e a Matrícula!", "error");
        return;
    }

    const payload = { nome, matricula, funcao: funcaoMapeada, periodoId };

    try {
        const method = editandoId ? "PUT" : "POST";
        const url = editandoId ? `${API_URL}/funcionarios/${editandoId}` : `${API_URL}/funcionarios`;
        
        const res = await fetch(url, {
            method: method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        if (res.ok) {
            showToast(editandoId ? "Colaborador atualizado!" : "Colaborador cadastrado!");
            limparFormFuncionario();
            await carregarListaFuncionarios();
            await carregarSeletoresFormularios();
            if(document.getElementById("nav-equipe-lista")) document.getElementById("nav-equipe-lista").checked = true;
            return;
        }
    } catch (error) {}

    if (!editandoId) {
        payload.id = Date.now();
        cacheFuncionarios.push(payload);
        showToast("Cadastrado localmente!");
    } else {
        cacheFuncionarios = cacheFuncionarios.map(f => f.id === editandoId ? { ...f, ...payload } : f);
        showToast("Atualizado localmente!");
    }
    
    localStorage.setItem("SGC_cache_funcionarios", JSON.stringify(cacheFuncionarios));
    limparFormFuncionario();
    await carregarListaFuncionarios();
    await carregarSeletoresFormularios();
    
    const tabLista = document.getElementById("nav-equipe-lista");
    if(tabLista) tabLista.checked = true;
}

function prepararEdicaoFuncionario(func) {
    editandoId = func.id;
    document.getElementById("txt-func-nome").value = func.nome;
    document.getElementById("txt-func-matricula").value = func.matricula;
    if(document.getElementById("sel-func-funcao")) document.getElementById("sel-func-funcao").value = func.funcao;
    if(document.getElementById("nav-equipe-form")) document.getElementById("nav-equipe-form").checked = true;
}

async function deletarFuncionario(id) {
    if (!confirm("Deseja remover este funcionário?")) return;

    try {
        const res = await fetch(`${API_URL}/funcionarios/${id}`, { method: "DELETE" });
        if (res.ok) {
            showToast("Funcionário removido!");
            carregarListaFuncionarios();
            carregarSeletoresFormularios();
        }
    } catch (error) {
        cacheFuncionarios = cacheFuncionarios.filter(f => f.id !== id);
        localStorage.setItem("SGC_cache_funcionarios", JSON.stringify(cacheFuncionarios));
        showToast("Removido localmente!");
        carregarListaFuncionarios();
        carregarSeletoresFormularios();
    }
}

function limparFormFuncionario() {
    editandoId = null;
    if(document.getElementById("txt-func-nome")) document.getElementById("txt-func-nome").value = "";
    if(document.getElementById("txt-func-matricula")) document.getElementById("txt-func-matricula").value = "";
}

/* ==========================================================================
   CRUD: AMBIENTES (Locais)
========================================================================== */
async function carregarListaLocais() {
    const container = document.getElementById("lista-locais-container");
    if (!container) return;

    let ambientesLocais = JSON.parse(localStorage.getItem("SGC_locais_fallback")) || [];

    try {
        const res = await fetch(`${API_URL}/ambientes`);
        if(res.ok) {
            ambientesLocais = await res.json();
            localStorage.setItem("SGC_locais_fallback", JSON.stringify(ambientesLocais));
        }
    } catch (error) {}

    if (ambientesLocais.length === 0) {
        container.innerHTML = `<p class="no-alerts">Nenhum local mapeado.</p>`;
        return;
    }

    container.innerHTML = ambientesLocais.map(amb => {
        let corStatus = "var(--verde)";
        if (amb.statusAmbiente === "sujo" || amb.statusAmbiente === "Pendente de Limpeza") corStatus = "var(--vermelho-btn)";
        if (amb.statusAmbiente === "pendente") corStatus = "var(--amarelo-texto)";

        return `
        <div class="crud-item-card">
            <div class="crud-icon-box" style="background-color: ${corStatus}">📍</div>
            <div class="crud-details">
                <h4>${amb.nome}</h4>
                <p>Setor: ${amb.localizacao || "Geral"} | Tipo: ${amb.tipo || "Operacional"}</p>
                <p style="color:${corStatus}; font-weight:bold; font-size:12px;">Status: ${(amb.statusAmbiente || "PENDENTE").toUpperCase()}</p>
            </div>
            <div class="crud-actions">
                <span onclick='prepararEdicaoLocal(${JSON.stringify(amb)})'>✏️</span>
                <span onclick="deletarLocal(${amb.id})">🗑️</span>
            </div>
        </div>
        `;
    }).join('');
}

async function salvarLocal() {
    const nomeInput = document.getElementById("txt-local-nome");
    if (!nomeInput) return;
    const nome = nomeInput.value.trim();

    const inputLocalizacao = document.getElementById("txt-local-vaga") || document.getElementById("txt-local-localizacao") || document.querySelector("input[placeholder*='Setor']");
    const localizacao = inputLocalizacao ? inputLocalizacao.value.trim() : "Geral";

    const tipoSelect = document.getElementById("sel-local-tipo");
    const tipo = tipoSelect ? tipoSelect.value : "sala"; 

    const statusSelect = document.getElementById("sel-local-status") || document.querySelector("select[id*='status']");
    const statusAmbiente = statusSelect ? statusSelect.value : "pendente";

    if (!nome) {
        showToast("Insira o Nome do ambiente!", "error");
        return;
    }

    const dto = { nome, localizacao, tipo, statusAmbiente };

    try {
        let url = `${API_URL}/ambientes`;
        let method = "POST";
        if (editandoId) {
            url += `/${editandoId}`;
            method = "PUT";
        }
        
        const res = await fetch(url, {
            method: method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(dto)
        });

        if (res.ok) {
            showToast("Ambiente salvo!");
            limparFormLocal();
            await carregarListaLocais();
            await carregarSeletoresFormularios();
            carregarPainelGerente(); 
            if(document.getElementById("nav-locais-lista")) document.getElementById("nav-locais-lista").checked = true;
            return;
        }
    } catch (error) {}

    let bancoLocal = JSON.parse(localStorage.getItem("SGC_locais_fallback")) || [];
    if (!editandoId) {
        dto.id = Date.now();
        bancoLocal.push(dto);
        showToast("Ambiente cadastrado!");
    } else {
        bancoLocal = bancoLocal.map(amb => amb.id === editandoId ? { ...amb, ...dto, id: editandoId } : amb);
        showToast("Ambiente atualizado!");
    }
    
    localStorage.setItem("SGC_locais_fallback", JSON.stringify(bancoLocal));
    limparFormLocal();
    await carregarListaLocais();
    await carregarSeletoresFormularios();
    carregarPainelGerente(); 
    
    const radioLista = document.getElementById("nav-locais-lista");
    if(radioLista) radioLista.checked = true;
}

function prepararEdicaoLocal(amb) {
    editandoId = amb.id;
    document.getElementById("txt-local-nome").value = amb.nome;
    
    const inputLocalizacao = document.getElementById("txt-local-vaga") || document.getElementById("txt-local-localizacao") || document.querySelector("input[placeholder*='Setor']");
    if(inputLocalizacao) inputLocalizacao.value = amb.localizacao || "";
    
    if(document.getElementById("sel-local-tipo")) document.getElementById("sel-local-tipo").value = amb.tipo;
    
    const statusSelect = document.getElementById("sel-local-status") || document.querySelector("select[id*='status']");
    if(statusSelect) statusSelect.value = amb.statusAmbiente;
    
    if(document.getElementById("nav-locais-form")) document.getElementById("nav-locais-form").checked = true;
}

async function deletarLocal(id) {
    if (!confirm("Deseja deletar este local?")) return;

    try {
        const res = await fetch(`${API_URL}/ambientes/${id}`, { method: "DELETE" });
        if (res.ok) {
            showToast("Local removido.");
            carregarListaLocais();
            carregarSeletoresFormularios();
            carregarPainelGerente(); 
        }
    } catch (error) {
        let bancoLocal = JSON.parse(localStorage.getItem("SGC_locais_fallback")) || [];
        bancoLocal = bancoLocal.filter(amb => amb.id !== id);
        localStorage.setItem("SGC_locais_fallback", JSON.stringify(bancoLocal));
        showToast("Removido localmente!");
        carregarListaLocais();
        carregarSeletoresFormularios();
        carregarPainelGerente(); 
    }
}

function limparFormLocal() {
    editandoId = null;
    if(document.getElementById("txt-local-nome")) document.getElementById("txt-local-nome").value = "";
    const inputLocalizacao = document.getElementById("txt-local-vaga") || document.getElementById("txt-local-localizacao") || document.querySelector("input[placeholder*='Setor']");
    if(inputLocalizacao) inputLocalizacao.value = "";
}

/* ==========================================================================
   CRUD: ESCALA CRONOGRAMA SEMANAL
========================================================================== */
async function carregarListaEscalas() {
    const container = document.getElementById("lista-escalas-container");
    if (!container) return;

    let cronogramas = JSON.parse(localStorage.getItem("SGC_escalas_fallback")) || [];

    try {
        const res = await fetch(`${API_URL}/cronogramas`);
        if(res.ok) {
            const dadosApi = await res.json();
            if (dadosApi && dadosApi.length > 0) {
                cronogramas = dadosApi;
                localStorage.setItem("SGC_escalas_fallback", JSON.stringify(cronogramas));
            }
        }
    } catch (error) {
        console.log("Modo offline: Carregando escalas locais.");
    }

    const diaAba = diaSelecionado.substring(0, 3).toLowerCase();
    const escalasDoDia = cronogramas.filter(c => {
        if (!c.diaSemana) return false;
        return c.diaSemana.toLowerCase().includes(diaAba);
    });

    if (escalasDoDia.length === 0) {
        container.innerHTML = `
            <label class="escala-slot-empty" for="nav-escala-form" style="cursor:pointer; display:block; padding:20px; text-align:center; border: 2px dashed #ccc; border-radius: 8px; color: #666; margin-top: 15px;">
                + Nenhuma escala para esta ${diaSelecionado}. Clique para adicionar.
            </label>`;
        return;
    }

    container.innerHTML = escalasDoDia.map(cron => `
        <div class="escala-slot" style="border: 1px solid #ccc; padding: 15px; margin-top: 15px; border-radius: 8px; background: #fff; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
            <div style="font-weight: bold; color: #1a56db; font-size: 16px; margin-bottom: 5px;">📍 ${cron.ambiente ? cron.ambiente.nome : 'Ambiente Geral'}</div>
            <div style="margin-bottom: 3px;"><strong>Tarefa:</strong> ${cron.tarefa ? cron.tarefa.descricao : 'Limpeza Geral'}</div>
            <div style="margin-bottom: 3px;"><strong>Responsável:</strong> ${cron.funcionario ? cron.funcionario.nome : 'Sem Colaborador'}</div>
            <div style="margin-bottom: 8px; color: #555;">⏰ <strong>Horário:</strong> ${cron.horarioInicio ? cron.horarioInicio.substring(0,5) : '00:00'}h às ${cron.horarioFim ? cron.horarioFim.substring(0,5) : '00:00'}h</div>
            <div class="crud-actions" style="margin-top:10px; display:flex; justify-content:flex-end; gap: 15px; font-size: 18px; cursor: pointer;">
                <span onclick='prepararEdicaoEscala(${JSON.stringify(cron)})' title="Editar">✏️</span>
                <span onclick="deletarEscala(${cron.idCronograma})" title="Excluir">🗑️</span>
            </div>
        </div>
    `).join('');
}

async function salvarEscala() {
    const funcSelect = document.getElementById("sel-escala-func");
    const localSelect = document.getElementById("sel-escala-local");
    const tarefaSelect = document.getElementById("sel-escala-tarefa");
    const diaSelect = document.getElementById("sel-escala-dia");
    const inicioInput = document.getElementById("time-escala-inicio");
    const fimInput = document.getElementById("time-escala-fim");

    if(!funcSelect || !localSelect || !inicioInput || !fimInput) {
        showToast("Erro: Estrutura do HTML inválida. Verifique os IDs.", "error");
        return;
    }

    let diaLimpo = diaSelecionado; 
    
    if (diaSelect && diaSelect.selectedIndex >= 0) {
        let textoDiaSelecionado = diaSelect.options[diaSelect.selectedIndex].text.toLowerCase();
        if (textoDiaSelecionado.includes("seg")) diaLimpo = "segunda";
        else if (textoDiaSelecionado.includes("ter")) diaLimpo = "terça";
        else if (textoDiaSelecionado.includes("qua")) diaLimpo = "quarta";
        else if (textoDiaSelecionado.includes("qui")) diaLimpo = "quinta";
        else if (textoDiaSelecionado.includes("sex")) diaLimpo = "sexta";
    }

    const dto = {
        funcionarioId: parseInt(funcSelect.value),
        ambienteId: parseInt(localSelect.value),
        tarefaId: tarefaSelect ? parseInt(tarefaSelect.value) : 1,
        diaSemana: diaLimpo,
        horarioInicio: inicioInput.value + ":00",
        horarioFim: fimInput.value + ":00"
    };

    if (!inicioInput.value || !fimInput.value || isNaN(dto.funcionarioId) || isNaN(dto.ambienteId)) {
        showToast("Preencha todos os campos e selecione os responsáveis!", "error");
        return;
    }

    try {
        let url = `${API_URL}/cronogramas`;
        let method = "POST";
        if (editandoId) {
            url += `/${editandoId}`;
            method = "PUT";
        }

        const res = await fetch(url, {
            method: method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(dto)
        });

        if (res.ok) {
            showToast("Cronograma salvo na API!");
            finalizarSalvamentoEscala();
            return;
        }
    } catch (error) {}

    let bancoEscalas = JSON.parse(localStorage.getItem("SGC_escalas_fallback")) || [];
    const funcCache = cacheFuncionarios.find(f => f.id === dto.funcionarioId) || { nome: funcSelect.options[funcSelect.selectedIndex].text };
    
    let locaisLista = JSON.parse(localStorage.getItem("SGC_locais_fallback")) || [];
    const ambCache = locaisLista.find(a => a.id === dto.ambienteId) || { nome: localSelect.options[localSelect.selectedIndex].text };
    
    const nomeTarefa = tarefaSelect && tarefaSelect.options[tarefaSelect.selectedIndex] 
                       ? tarefaSelect.options[tarefaSelect.selectedIndex].text 
                       : "Limpeza Padrão";

    const novaEscala = {
        idCronograma: editandoId || Date.now(),
        funcionario: funcCache,
        ambiente: ambCache,
        tarefa: { id: dto.tarefaId, descricao: nomeTarefa },
        diaSemana: diaLimpo,
        horarioInicio: dto.horarioInicio,
        horarioFim: dto.horarioFim
    };

    if (!editandoId) {
        bancoEscalas.push(novaEscala);
        showToast("Escala salva localmente (Offline)!");
    } else {
        bancoEscalas = bancoEscalas.map(e => e.idCronograma === editandoId ? novaEscala : e);
        showToast("Escala atualizada localmente!");
    }
    
    localStorage.setItem("SGC_escalas_fallback", JSON.stringify(bancoEscalas));
    finalizarSalvamentoEscala();
}

function finalizarSalvamentoEscala() {
    limparFormEscala();
    carregarListaEscalas();
    const radioLista = document.getElementById("nav-escala-lista");
    if(radioLista) radioLista.checked = true;
}

function prepararEdicaoEscala(cron) {
    editandoId = cron.idCronograma;
    if(document.getElementById("sel-escala-func")) document.getElementById("sel-escala-func").value = cron.funcionario ? cron.funcionario.id : "";
    if(document.getElementById("sel-escala-local")) document.getElementById("sel-escala-local").value = cron.ambiente ? cron.ambiente.id : "";
    if(document.getElementById("sel-escala-tarefa")) document.getElementById("sel-escala-tarefa").value = cron.tarefa ? cron.tarefa.id : "";
    
    const diaSelect = document.getElementById("sel-escala-dia");
    if(diaSelect) {
        const opcaoDia = Array.from(diaSelect.options).find(opt => opt.value.toLowerCase().includes(cron.diaSemana.toLowerCase()));
        if (opcaoDia) diaSelect.value = opcaoDia.value;
    }
    
    document.getElementById("time-escala-inicio").value = cron.horarioInicio ? cron.horarioInicio.substring(0,5) : "";
    document.getElementById("time-escala-fim").value = cron.horarioFim ? cron.horarioFim.substring(0,5) : "";
    
    const radioForm = document.getElementById("nav-escala-form");
    if(radioForm) radioForm.checked = true;
}

async function deletarEscala(id) {
    if (!confirm("Remover este horário da grade?")) return;

    try {
        const res = await fetch(`${API_URL}/cronogramas/${id}`, { method: "DELETE" });
        if (res.ok) {
            showToast("Escala excluída.");
            carregarListaEscalas();
            return;
        }
    } catch (error) {}

    let bancoEscalas = JSON.parse(localStorage.getItem("SGC_escalas_fallback")) || [];
    bancoEscalas = bancoEscalas.filter(e => e.idCronograma !== id);
    localStorage.setItem("SGC_escalas_fallback", JSON.stringify(bancoEscalas));
    showToast("Removido localmente!");
    carregarListaEscalas();
}

function limparFormEscala() {
    editandoId = null;
    if(document.getElementById("time-escala-inicio")) document.getElementById("time-escala-inicio").value = "";
    if(document.getElementById("time-escala-fim")) document.getElementById("time-escala-fim").value = "";
}
function atualizarPainelGerente() {
    let locais = JSON.parse(localStorage.getItem('sgc_locais')) || [];
    
    let qtdLimpos = 0;
    let qtdPendentes = 0;
    let qtdSujos = 0;

    locais.forEach(local => {
        if (local.status === 'limpo') qtdLimpos++;
        if (local.status === 'pendente') qtdPendentes++;
        if (local.status === 'sujo') qtdSujos++;
    });

    let elementoLimpos = document.querySelector('.stat-item.blue h2');
    let elementoPendentes = document.querySelector('.stat-item.yellow h2');
    let elementoSujos = document.querySelector('.stat-item.red-alert h2');

    if (elementoLimpos) elementoLimpos.innerText = qtdLimpos;
    if (elementoPendentes) elementoPendentes.innerText = qtdPendentes;
    if (elementoSujos) elementoSujos.innerText = qtdSujos;
}
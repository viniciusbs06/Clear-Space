document.addEventListener("DOMContentLoaded", () => {
    const usuario = getUsuarioLogado();
    const elNome = document.querySelector(".header-operacional h2");
    if (usuario && usuario.nome && elNome) {
        elNome.innerText = `Olá, ${usuario.nome.split(" ")[0]}`;
    }
    atualizarBadgeNotificacoes();
});

document.addEventListener("notificacoes:atualizadas", () => {
    atualizarBadgeNotificacoes();

    const painel = document.getElementById("painel-notificacoes");
    if (painel && painel.style.display === "block") {
        renderizarListaNotificacoes();
    }
});

function formatarDataNotificacao(dataIso) {
    if (!dataIso) return "";
    const data = new Date(dataIso);
    if (isNaN(data.getTime())) return dataIso;
    return data.toLocaleDateString('pt-BR') + " " + data.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

function atualizarBadgeNotificacoes() {
    const badge = document.getElementById("badge-notificacoes");
    if (!badge) return;

    const naoLidas = contarNotificacoesNaoLidas();
    if (naoLidas > 0) {
        badge.innerText = naoLidas > 9 ? "9+" : naoLidas;
        badge.style.display = "block";
    } else {
        badge.style.display = "none";
    }
}

function renderizarListaNotificacoes() {
    const container = document.getElementById("lista-notificacoes-container");
    if (!container) return;

    const notificacoes = listarNotificacoes()
        .slice()
        .sort((a, b) => new Date(b.dataHora) - new Date(a.dataHora));

    if (notificacoes.length === 0) {
        container.innerHTML = `<p style="padding:20px; text-align:center; color:#999; font-size:13px;">Nenhuma notificação por aqui.</p>`;
        return;
    }

    container.innerHTML = notificacoes.map(n => `
        <div style="padding:12px 15px; border-bottom:1px solid #f2f2f2; ${n.lida ? '' : 'background:#eaf4fd;'}">
            <div style="font-weight:700; font-size:13px; color:#1a56db; margin-bottom:3px;">${n.titulo}</div>
            <div style="font-size:13px; color:#444; margin-bottom:5px;">${n.mensagem}</div>
            <div style="font-size:11px; color:#999;">${formatarDataNotificacao(n.dataHora)}</div>
        </div>
    `).join('');
}

function toggleNotificacoes() {
    const painel = document.getElementById("painel-notificacoes");
    if (!painel) return;

    const vaiAbrir = painel.style.display === "none" || !painel.style.display;

    if (vaiAbrir) {
        renderizarListaNotificacoes();
        painel.style.display = "block";
        marcarNotificacoesComoLidas();
        atualizarBadgeNotificacoes();
    } else {
        painel.style.display = "none";
    }
}

function limparNotificacoesTela() {
    limparNotificacoes();
    renderizarListaNotificacoes();
    atualizarBadgeNotificacoes();
}

document.addEventListener("click", (e) => {
    const painel = document.getElementById("painel-notificacoes");
    const btn = document.getElementById("btn-notificacoes");
    if (!painel || painel.style.display === "none" || painel.style.display === "") return;
    if (!painel.contains(e.target) && !btn.contains(e.target)) {
        painel.style.display = "none";
    }
});
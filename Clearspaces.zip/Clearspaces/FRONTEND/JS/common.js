const API_URL = "http://localhost:8080";

function showToast(mensagem, tipo = "success") {
    const container = document.getElementById("toast-container") || criarToastContainer();
    const toast = document.createElement("div");
    toast.className = `toast toast-${tipo}`;
    toast.innerText = mensagem;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

function criarToastContainer() {
    const container = document.createElement("div");
    container.id = "toast-container";
    const appContainer = document.querySelector(".app-container") || document.body;
    appContainer.appendChild(container);
    return container;
}

function getUsuarioLogado() {
    return JSON.parse(localStorage.getItem("SGC_usuario_logado")) || null;
}

function logout() {
    // limpa também o cache de notificações do usuário que está saindo,
    // para não vazar histórico entre logins diferentes no mesmo navegador
    const chave = getChaveCacheNotificacoes();
    if (chave) localStorage.removeItem(chave);
    localStorage.removeItem("SGC_usuario_logado");
}

// ===================== GERENCIAMENTO DE NOTIFICAÇÕES (API REST + SSE + CACHE LOCAL) =====================
let notificacoesCache = [];

function getChaveCacheNotificacoes() {
    const usuario = getUsuarioLogado();
    if (!usuario || !usuario.id) return null;
    return `SGC_notificacoes_cache_${usuario.id}`;
}

// Lê o cache salvo no navegador. Garante que a lista apareça na hora,
// mesmo antes (ou no lugar, se a API falhar) da resposta do backend chegar.
function carregarNotificacoesDoCacheLocal() {
    const chave = getChaveCacheNotificacoes();
    if (!chave) return;

    try {
        const salvas = JSON.parse(localStorage.getItem(chave));
        if (Array.isArray(salvas)) {
            notificacoesCache = salvas;
        }
    } catch (error) {
        console.warn("Não foi possível ler o cache local de notificações.", error);
    }
}

// Persiste o estado atual (incluindo as já lidas) para sobreviver a um F5
function salvarNotificacoesNoCacheLocal() {
    const chave = getChaveCacheNotificacoes();
    if (!chave) return;

    try {
        localStorage.setItem(chave, JSON.stringify(notificacoesCache));
    } catch (error) {
        console.warn("Não foi possível salvar o cache local de notificações.", error);
    }
}

// Une a lista vinda do backend com a lista local, sem perder nenhuma notificação
// (ex: uma recebida via SSE que ainda não constava na resposta da API)
function mesclarNotificacoes(remotas, locais) {
    const mapa = new Map();

    locais.forEach(n => mapa.set(String(n.id), n));
    // o backend é a fonte de verdade para o status "lida", então sobrescreve por último
    remotas.forEach(n => mapa.set(String(n.id), n));

    return Array.from(mapa.values()).sort((a, b) => new Date(b.dataHora) - new Date(a.dataHora));
}

// Avisa qualquer tela que esteja ouvindo que o cache de notificações mudou
// (evita depender de "typeof funcao === 'function'" e da ordem dos scripts)
function notificarAtualizacaoNotificacoes() {
    document.dispatchEvent(new CustomEvent("notificacoes:atualizadas"));
}

// 1. Busca o histórico de notificações salvas no Banco de Dados via Spring Boot
async function carregarNotificacoesDoBackend() {
    const usuario = getUsuarioLogado();
    if (!usuario || !usuario.id) return;

    try {
        const res = await fetch(`${API_URL}/notificacoes/usuario/${usuario.id}`);
        if (res.ok) {
            const remotas = await res.json();
            notificacoesCache = remotas.sort((a, b) => new Date(b.dataHora) - new Date(a.dataHora));
            salvarNotificacoesNoCacheLocal();
            notificarAtualizacaoNotificacoes();
        }
    } catch (error) {
        console.warn("API offline ao carregar histórico de notificações do banco. Mantendo cache local.");
    }
}
function listarNotificacoes() {
    return notificacoesCache;
}

function contarNotificacoesNaoLidas() {
    return notificacoesCache.filter(n => !n.lida).length;
}

async function marcarNotificacoesComoLidas() {
    notificacoesCache.forEach(n => n.lida = true);
    salvarNotificacoesNoCacheLocal();
    notificarAtualizacaoNotificacoes();

    const usuario = getUsuarioLogado();
    if (!usuario || !usuario.id) return;

    try {
        await fetch(`${API_URL}/notificacoes/ler/${usuario.id}`, { method: "PUT" });
    } catch (error) {
        console.error("Erro ao atualizar status de leitura no servidor:", error);
    }
}

// Limpa apenas a exibição local; não apaga o histórico do servidor
function limparNotificacoes() {
    notificacoesCache = [];
    salvarNotificacoesNoCacheLocal();
    notificarAtualizacaoNotificacoes();
}

// 2. Escuta novos alertas em tempo real enviados pelo Spring Boot via SSE
function iniciarEscutaSSE() {
    const usuario = getUsuarioLogado();
    if (!usuario || !usuario.id) return;

    const eventSource = new EventSource(`${API_URL}/notificacoes/stream/${usuario.id}`);

    eventSource.addEventListener("ambiente-liberado", (event) => {
        const mensagem = event.data;
        const titulo = "🧹 Sala Liberada";

        // Insere a notificação recebida do servidor no topo da lista atual
        notificacoesCache.unshift({
            id: Date.now(),
            titulo: titulo,
            mensagem: mensagem,
            dataHora: new Date().toISOString(),
            lida: false
        });
        salvarNotificacoesNoCacheLocal();

        showToast(`🔔 ${titulo}: ${mensagem}`, "info");
        notificarAtualizacaoNotificacoes();

        if (typeof carregarMinhasTarefasHoje === "function") {
            carregarMinhasTarefasHoje();
        }
    });

    eventSource.onerror = (error) => {
        console.warn("Conexão SSE perdida. Tentando reconectar ao servidor...", error);
    };
}

// Inicializa ao carregar qualquer página
document.addEventListener("DOMContentLoaded", async () => {
    carregarNotificacoesDoCacheLocal();
    notificarAtualizacaoNotificacoes(); // já mostra o que tinha salvo, antes mesmo da API responder
    await carregarNotificacoesDoBackend();
    iniciarEscutaSSE();
});
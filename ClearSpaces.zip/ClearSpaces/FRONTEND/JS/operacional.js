/* ==========================================================================
   CLEAR SPACE - PAINEL DO OPERADOR (operacional.html)
   Depende de: common.js
========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
    const usuario = getUsuarioLogado();
    const elNome = document.querySelector(".header-operacional h2");
    if (usuario && usuario.nome && elNome) {
        elNome.innerText = `Olá, ${usuario.nome.split(" ")[0]}`;
    }
});

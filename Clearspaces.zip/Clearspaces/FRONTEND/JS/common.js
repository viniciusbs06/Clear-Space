const API_URL = 'http://localhost:8080'; // Ajuste o endereço da sua API

document.addEventListener("DOMContentLoaded", () => {
    const inputIdentificacao = document.getElementById('login-identificacao');

    if (inputIdentificacao) {
        inputIdentificacao.addEventListener('input', (e) => {
            let valor = e.target.value;

            // Se o primeiro caractere for um número, aplica a máscara de CPF
            if (/^\d/.test(valor)) {
                let v = valor.replace(/\D/g, "").substring(0, 11);
                
                if (v.length > 9) {
                    v = v.replace(/^(\d{3})(\d{3})(\d{3})(\d{1,2})/, "$1.$2.$3-$4");
                } else if (v.length > 6) {
                    v = v.replace(/^(\d{3})(\d{3})(\d{1,3})/, "$1.$2.$3");
                } else if (v.length > 3) {
                    v = v.replace(/^(\d{3})(\d{1,3})/, "$1.$2");
                }
                
                e.target.value = v;
            } else {
                // Se for matrícula (FUNC- ou PROF-), força maiúsculas e limita tamanho
                e.target.value = valor.toUpperCase().substring(0, 9);
            }
        });
    }
});

// Identifica o tipo de entrada (CPF ou Matrícula) e constrói o DTO adequado
function extrairIdentificacao(identificacao) {
    const texto = identificacao.trim();
    const textoUpper = texto.toUpperCase();
    const apenasNumeros = texto.replace(/\D/g, '');

    if (/^FUNC-\d{4}$/i.test(texto)) {
        return { tipo: 'FUNCIONARIO', dto: { cpf: null, matricula: textoUpper } };
    }

    if (/^PROF-\d{4}$/i.test(texto)) {
        return { tipo: 'PROFESSOR', dto: { cpf: null, matricula: textoUpper } };
    }

    if (apenasNumeros.length === 11) {
        return { tipo: 'CPF', dto: { cpf: apenasNumeros, matricula: null } };
    }

    return { tipo: 'DESCONHECIDO', dto: { cpf: texto, matricula: texto } };
}
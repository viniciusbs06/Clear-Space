use clearSpaces;

select * from funcionario;
select * from periodo;
select * from ambiente;

INSERT INTO funcionario (nome, cpf, matricula, senha) 
VALUES ('gestor', '12345678901', '1021', '123456');
INSERT INTO funcionario (funcao, matricula, nome, periodo_id, cpf, senha) 
VALUES ('gerente', 'EXU12345', 'João Silva', 1, '11145678901', 'senha123');
INSERT INTO funcionario (funcao, matricula, nome, periodo_id, cpf, senha) 
VALUES ('asg', 'EUU12345', 'João pedro', 1, '14145678901', 'senha123');
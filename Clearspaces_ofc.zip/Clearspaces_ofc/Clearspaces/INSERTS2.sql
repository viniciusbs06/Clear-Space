use clearSpaces;

select * from ambiente;
select * from atribuicao;
select * from cronograma;
select * from funcionario;
select * from notificacao;
select * from ocorrencia;
select * from periodo;
select * from professor;
select * from tarefa;

INSERT INTO funcionario (funcao, matricula, nome, periodo_id, cpf, senha) 
VALUES ('gerente', 'FUNC-1234', 'João Silva', 1, '11111111111', 'senha123');

INSERT INTO funcionario (funcao, matricula, nome, periodo_id, cpf, senha) 
VALUES ('asg', 'FUNC-1235', 'Nicolas Pereira', 2, '11111111112', 'senha123');

INSERT INTO funcionario (funcao, matricula, nome, periodo_id, cpf, senha) 
VALUES ('banheirista', 'FUNC-1236', 'Maria Oliveira', 1, '11111111114', 'senha123');

INSERT INTO funcionario (funcao, matricula, nome, periodo_id, cpf, senha) 
VALUES ('asg', 'FUNC-1237', 'Carlos Souza', 2, '11111111115', 'senha123');

INSERT INTO funcionario (funcao, matricula, nome, periodo_id, cpf, senha) 
VALUES ('banheirista', 'FUNC-1238', 'Ana Santos', 3, '11111111116', 'senha123');

INSERT INTO professor (matricula, nome, periodo_id, cpf, senha) 
VALUES ('PROF-1232', 'Vinicius Lira', 3, '11111111113', 'senha123');

INSERT INTO professor (matricula, nome, periodo_id, cpf, senha) 
VALUES ('PROF-1233', 'Mariana Costa', 1, '11111111117', 'senha123');

INSERT INTO professor (matricula, nome, periodo_id, cpf, senha) 
VALUES ('PROF-1234', 'Roberto Alves', 2, '11111111118', 'senha123');
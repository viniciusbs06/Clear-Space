use clearSpaces;

select * from funcionario;
select * from periodo;

INSERT INTO funcionario (funcao, matricula, nome, periodo_id, cpf, senha) 
VALUES ('asg', 'ASG12345', 'João Silva', 1, '12345678900', 'senha123');
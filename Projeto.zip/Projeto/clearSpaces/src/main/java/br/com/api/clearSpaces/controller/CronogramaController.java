package br.com.api.clearSpaces.controller;

import br.com.api.clearSpaces.dto.CronogramaDTO;
import br.com.api.clearSpaces.entity.Cronograma;
import br.com.api.clearSpaces.service.CronogramaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/cronogramas")
@CrossOrigin("*")
public class CronogramaController {

    @Autowired
    private CronogramaService cronogramaService;

    @PostMapping
    public void criar(@RequestBody CronogramaDTO dto) {
        cronogramaService.salvar(dto);
    }

    @GetMapping
    public List<Cronograma> listar() {
        return cronogramaService.listarTodos();
    }

    @PutMapping("/{id}")
    public void atualizar(@PathVariable Long id, @RequestBody CronogramaDTO dto) {
        cronogramaService.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id) {
        cronogramaService.deletar(id);
    }
}
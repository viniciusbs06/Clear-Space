use clearSpaces;

select * from funcionario;
select * from periodo;
select * from ambiente;

INSERT INTO funcionario (funcao, matricula, nome, periodo_id, cpf, senha) 
VALUES ('gerente', 'FUNC-1234', 'João Silva', 1, '11111111111', 'senha123');

INSERT INTO funcionario (funcao, matricula, nome, periodo_id, cpf, senha) 
VALUES ('asg', 'FUNC-1235', 'Nicolas Pereira', 2, '11111111112', 'senha123');

INSERT INTO professor (matricula, nome, periodo_id, cpf, senha) 
VALUES ('PROF-1232', 'Vinicius Lira', 3, '11111111113', 'senha123');
package br.com.api.clearSpaces.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "ambiente")
public class Ambiente {

    @Id
    @GeneratedValue
    private Long id;

    private String descricao;
    private enum tipo{
        sala,banheiro,pendente
    }
    private String localizacao;
    private enum status_ambiente{
        limpo,sujo,pendente
    }

    protected Aluno(){}

    public Aluno(String descricao, tipo, String localizacao, status_ambiente){

    }
}

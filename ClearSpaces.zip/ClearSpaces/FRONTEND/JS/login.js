async function fazerLogin(event) {
    if (event) event.preventDefault();

    const identificacao = document.getElementById('login-identificacao').value.trim();
    const senha = document.getElementById('login-senha').value.trim();

    if (!identificacao || !senha) {
        alert('Por favor, preencha o login e a senha!');
        return;
    }

    const loginDTO = {
        cpf: identificacao,
        matricula: identificacao,
        senha: senha
    };

    try {
        const response = await fetch(`${API_URL}/funcionarios`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(loginDTO)
        });

        if (response.ok) {
            const usuario = await response.json(); 


            localStorage.setItem('SGC_usuario_logado', JSON.stringify(usuario));

            alert(`Seja bem-vindo, ${usuario.nome}!`);

            const funcao = (usuario.funcao || '').toUpperCase();

            
            if (funcao === 'GERENTE') {
                window.location.href = 'gerente.html';
            } else {
                window.location.href = 'operacional.html';
            }
        } else {
            const erroMsg = await response.text();
            alert(erroMsg || 'Usuário ou senha incorretos.');
        }
    } catch (error) {
        console.error('Erro ao realizar login:', error);
        alert('Erro ao conectar com o servidor Spring Boot.');
    }
}

async function redefinirSenha(event) {
    if (event) event.preventDefault();
    
    const identificacao = prompt("Digite seu CPF ou Matrícula:");
    if (!identificacao) return;

    const novaSenha = prompt("Digite a sua nova senha:");
    if (!novaSenha) return;

    const esqueciDTO = {
        cpf: identificacao,
        matricula: identificacao,
        novaSenha: novaSenha
    };

    try {
        const response = await fetch(`${API_URL}/funcionarios/esqueci-senha`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(esqueciDTO)
        });

        const mensagem = await response.text();

        if (response.ok) {
            alert(mensagem); // "Senha atualizada com sucesso!"
        } else {
            alert(mensagem || 'Erro ao redefinir a senha.');
        }
    } catch (error) {
        console.error('Erro ao redefinir senha:', error);
        alert('Erro ao conectar com o servidor Spring Boot.');
    }
}
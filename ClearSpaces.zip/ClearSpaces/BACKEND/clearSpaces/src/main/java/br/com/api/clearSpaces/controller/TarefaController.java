package br.com.api.clearSpaces.controller;

import br.com.api.clearSpaces.dto.TarefaDTO;
import br.com.api.clearSpaces.entity.Tarefa;
import br.com.api.clearSpaces.service.TarefaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tarefas")
@CrossOrigin("*")
public class TarefaController {

    private final TarefaService tarefaService;

    public TarefaController(TarefaService tarefaService) {
        this.tarefaService = tarefaService;
    }

    @PostMapping
    public void criar(@RequestBody TarefaDTO dto) {
        tarefaService.salvar(dto);
    }

    @GetMapping
    public List<Tarefa> listar() {
        return tarefaService.listarTodas();
    }

    @PutMapping("/{id}")
    public void atualizar(@PathVariable Long id, @RequestBody TarefaDTO dto) {
        tarefaService.atualizar(id, dto);
    }

    @PutMapping("/{id}/ft_antes")
    public void adicionarFotoAntes(@PathVariable Long id, @RequestBody TarefaDTO dto) {
        tarefaService.salvarFotoAntes(id, dto);
    }

    @PutMapping("/{id}/ft_depois")
    public void adicionarFotoDepois(@PathVariable Long id, @RequestBody TarefaDTO dto) {
        tarefaService.salvarFotoDepois(id, dto);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id) {
        tarefaService.deletar(id);
    }
}
const API_URL = 'http://localhost:8080'; // Ajuste o endereço da sua API

document.addEventListener("DOMContentLoaded", () => {
    const inputIdentificacao = document.getElementById('login-identificacao');

    if (inputIdentificacao) {
        inputIdentificacao.addEventListener('input', (e) => {
            let valor = e.target.value;

            // Se o primeiro caractere for um número, aplica a máscara de CPF
            if (/^\d/.test(valor)) {
                let v = valor.replace(/\D/g, "").substring(0, 11);

                if (v.length > 9) {
                    v = v.replace(/^(\d{3})(\d{3})(\d{3})(\d{1,2})/, "$1.$2.$3-$4");
                } else if (v.length > 6) {
                    v = v.replace(/^(\d{3})(\d{3})(\d{1,3})/, "$1.$2.$3");
                } else if (v.length > 3) {
                    v = v.replace(/^(\d{3})(\d{1,3})/, "$1.$2");
                }

                e.target.value = v;
            } else {
                // Se for matrícula (FUNC- ou PROF-), força maiúsculas e limita tamanho
                e.target.value = valor.toUpperCase().substring(0, 9);
            }
        });
    }
});

// Identifica o tipo de entrada (CPF ou Matrícula) e constrói o DTO adequado
function extrairIdentificacao(identificacao) {
    const texto = identificacao.trim();
    const textoUpper = texto.toUpperCase();
    const apenasNumeros = texto.replace(/\D/g, '');

    if (/^FUNC-\d{4}$/i.test(texto)) {
        return { tipo: 'FUNCIONARIO', dto: { cpf: null, matricula: textoUpper } };
    }

    if (/^PROF-\d{4}$/i.test(texto)) {
        return { tipo: 'PROFESSOR', dto: { cpf: null, matricula: textoUpper } };
    }

    if (apenasNumeros.length === 11) {
        return { tipo: 'CPF', dto: { cpf: apenasNumeros, matricula: null } };
    }

    return { tipo: 'DESCONHECIDO', dto: { cpf: texto, matricula: texto } };
}

// Monta o banner amarelo de aviso quando uma lista está mostrando dados
// salvos localmente porque a API não respondeu. Usado por todas as telas
// de listagem, pra você NUNCA achar que um dado sumiu ou é mais recente
// do que realmente é.
function avisoCacheHtml(usandoCache) {
    if (!usandoCache) return '';
    return `<p class="no-alerts" style="background:#fff3cd; color:#856404; border:1px solid #ffeeba; border-radius:8px; padding:10px; margin-bottom:15px;">⚠️ Não foi possível conectar ao servidor agora. Exibindo dados salvos localmente, que podem estar desatualizados.</p>`;
}

// ============================================================
// showToast — ESTA FUNÇÃO ESTAVA FALTANDO NO PROJETO.
// É chamada por quase todas as telas (listas e formulários) para
// mostrar uma notificação rápida (sucesso ou erro), mas nunca tinha
// sido implementada em lugar nenhum. Como ela não existia, toda vez
// que o código chamava showToast(...) o navegador lançava um erro
// (ReferenceError) e interrompia a execução do restante da função
// — inclusive o recarregamento da lista logo em seguida. Por isso
// os dados salvavam certinho no banco, mas a tela só atualizava
// depois de um F5 manual. Com esta função definida aqui, isso para
// de acontecer em TODAS as telas que importam common.js.
// ============================================================
function showToast(mensagem, tipo = "success") {
    injetarEstiloToast();

    let toast = document.getElementById("sgc-toast");
    if (!toast) {
        toast = document.createElement("div");
        toast.id = "sgc-toast";
        document.body.appendChild(toast);
    }

    toast.textContent = mensagem;
    toast.className = `sgc-toast sgc-toast-${tipo === "error" ? "error" : "success"} sgc-toast-show`;

    clearTimeout(toast._sgcTimeoutId);
    toast._sgcTimeoutId = setTimeout(() => {
        toast.classList.remove("sgc-toast-show");
    }, 3000);
}

function injetarEstiloToast() {
    if (document.getElementById("sgc-toast-style")) return;

    const style = document.createElement("style");
    style.id = "sgc-toast-style";
    style.textContent = `
        #sgc-toast {
            position: fixed;
            left: 50%;
            bottom: 30px;
            transform: translateX(-50%) translateY(20px);
            min-width: 220px;
            max-width: 90vw;
            padding: 12px 20px;
            border-radius: 8px;
            font-family: 'Inter', sans-serif;
            font-size: 14px;
            font-weight: 600;
            color: #fff;
            text-align: center;
            box-shadow: 0 4px 16px rgba(0,0,0,0.2);
            opacity: 0;
            pointer-events: none;
            z-index: 9999;
            transition: opacity .25s ease, transform .25s ease;
        }
        #sgc-toast.sgc-toast-show {
            opacity: 1;
            transform: translateX(-50%) translateY(0);
        }
        #sgc-toast.sgc-toast-success { background: #27ae60; }
        #sgc-toast.sgc-toast-error { background: #c0392b; }
    `;
    document.head.appendChild(style);
}

// ============================================================
// getUsuarioLogado — lê o usuário salvo no login (login.js salva
// em 'SGC_usuario_logado'). Estava sendo chamada em várias telas
// (func-tarefas, operacional, professor, func-ocorrencias,
// reserva-form) mas nunca tinha sido implementada — por isso
// essas telas travavam com ReferenceError e ficavam em branco.
// ============================================================
function getUsuarioLogado() {
    try {
        return JSON.parse(localStorage.getItem("SGC_usuario_logado"));
    } catch (e) {
        return null;
    }
}

// ============================================================
// Notificações — usadas pelo sino em operacional.js, também
// nunca implementadas em lugar nenhum.
// ============================================================
function listarNotificacoes() {
    return JSON.parse(localStorage.getItem("SGC_notificacoes")) || [];
}

function contarNotificacoesNaoLidas() {
    return listarNotificacoes().filter(n => !n.lida).length;
}

function marcarNotificacoesComoLidas() {
    const notifs = listarNotificacoes().map(n => ({ ...n, lida: true }));
    localStorage.setItem("SGC_notificacoes", JSON.stringify(notifs));
}

function limparNotificacoes() {
    localStorage.setItem("SGC_notificacoes", JSON.stringify([]));
}
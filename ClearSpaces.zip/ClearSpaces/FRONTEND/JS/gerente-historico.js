/* ==========================================================================
   CLEAR SPACE - HISTÓRICO GERAL DE OCORRÊNCIAS (gerente-historico-ocorrencias.html)
   Depende de: common.js
========================================================================== */

document.addEventListener("DOMContentLoaded", () => {
    carregarHistoricoGlobalGestor();
});

function carregarHistoricoGlobalGestor() {
    const container = document.getElementById("historico-global-gestor-container");
    if (!container) return;

    const ocorrenciasLocais = JSON.parse(localStorage.getItem("SGC_ocorrencias")) || [];

    if (ocorrenciasLocais.length === 0) {
        container.innerHTML = `<p class="no-alerts">Nenhuma ocorrência registrada até o momento.</p>`;
        return;
    }

    container.innerHTML = ocorrenciasLocais.slice().reverse().map(oc => `
        <div class="msg-historico-card">
            <div class="msg-header-line">
                <span class="badge-gravidade badge-${oc.gravidade}">${oc.gravidade}</span>
                <span class="msg-time-stamp">${oc.data}</span>
            </div>
            <div class="alerta-meta-info">Enviado por: <strong>${oc.remetente}</strong></div>
            <div class="msg-body-text">${oc.mensagem}</div>
            ${oc.status === 'resolvido'
                ? `<div class="status-resolvido-box">✓ Designado para: ${oc.encarregado}</div>`
                : `<div class="status-resolvido-box" style="background:#fff3cd; color:#856404; border-color:#ffeeba;">⏳ Aguardando leitura do Gestor</div>`
            }
        </div>
    `).join('');
}

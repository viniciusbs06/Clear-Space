package br.com.api.clearSpaces.dto;

public class OcorrenciaDTO {

    private Long funcionarioId;   // remetente, usado na criação
    private String gravidade;     // "leve" | "moderada" | "urgente"
    private String mensagem;
    private Long encarregadoId;   // usado na designação (gerente)

    public OcorrenciaDTO() {}

    public Long getFuncionarioId() {
        return funcionarioId;
    }

    public void setFuncionarioId(Long funcionarioId) {
        this.funcionarioId = funcionarioId;
    }

    public String getGravidade() {
        return gravidade;
    }

    public void setGravidade(String gravidade) {
        this.gravidade = gravidade;
    }

    public String getMensagem() {
        return mensagem;
    }

    public void setMensagem(String mensagem) {
        this.mensagem = mensagem;
    }

    public Long getEncarregadoId() {
        return encarregadoId;
    }

    public void setEncarregadoId(Long encarregadoId) {
        this.encarregadoId = encarregadoId;
    }
}
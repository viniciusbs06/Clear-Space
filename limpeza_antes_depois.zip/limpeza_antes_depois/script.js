const fotoAntes =
    document.getElementById("fotoAntes");

const fotoDepois =
    document.getElementById("fotoDepois");


const previewAntes =
    document.getElementById("previewAntes");

const previewDepois =
    document.getElementById("previewDepois");


const areaAntes =
    document.getElementById("areaAntes");

const areaDepois =
    document.getElementById("areaDepois");


const containerAntes =
    document.getElementById("containerAntes");

const containerDepois =
    document.getElementById("containerDepois");


const removerAntes =
    document.getElementById("removerAntes");

const removerDepois =
    document.getElementById("removerDepois");


const btnSalvar =
    document.getElementById("btnSalvar");


const mensagem =
    document.getElementById("mensagem");


const observacao =
    document.getElementById("observacao");


const contadorCaracteres =
    document.getElementById("contadorCaracteres");


const dataRegistro =
    document.getElementById("dataRegistro");


const cameraModal =
    document.getElementById("cameraModal");

const cameraVideo =
    document.getElementById("cameraVideo");


let cameraStream = null;

let cameraDestino = null;

function obterDataAtual() {

    const agora =
        new Date();

    const dia =
        String(
            agora.getDate()
        ).padStart(2, "0");

    const mes =
        String(
            agora.getMonth() + 1
        ).padStart(2, "0");

    const ano =
        agora.getFullYear();

    return `${dia}/${mes}/${ano}`;
}


dataRegistro.textContent =
    obterDataAtual();


function obterDataNomeArquivo() {

    const agora =
        new Date();

    const dia =
        String(
            agora.getDate()
        ).padStart(2, "0");

    const mes =
        String(
            agora.getMonth() + 1
        ).padStart(2, "0");

    const ano =
        agora.getFullYear();

    return `${dia}-${mes}-${ano}`;
}


function processarFoto(
    input,
    preview,
    area,
    container
) {

    const arquivo =
        input.files[0];


    if (!arquivo) {
        return;
    }


    if (
        !arquivo.type.startsWith("image/")
    ) {

        mostrarMensagem(
            "Selecione um arquivo de imagem válido.",
            "erro"
        );

        input.value = "";

        return;
    }

    const tamanhoMaximo =
        10 * 1024 * 1024;


    if (
        arquivo.size >
        tamanhoMaximo
    ) {

        mostrarMensagem(
            "A imagem deve ter no máximo 10 MB.",
            "erro"
        );

        input.value = "";

        return;
    }

    const reader =
        new FileReader();


    reader.onload =
        function(event) {

            preview.src =
                event.target.result;


            area.classList.add(
                "tem-foto"
            );


            container.classList.add(
                "tem-foto"
            );


            limparMensagem();
        };


    reader.readAsDataURL(
        arquivo
    );
}


function abrirGaleria(tipo) {

    if (tipo === "antes") {

        fotoAntes.click();

    } else {

        fotoDepois.click();

    }
}

fotoAntes.addEventListener(
    "change",
    function() {

        processarFoto(
            fotoAntes,
            previewAntes,
            areaAntes,
            containerAntes
        );

    }
);


fotoDepois.addEventListener(
    "change",
    function() {

        processarFoto(
            fotoDepois,
            previewDepois,
            areaDepois,
            containerDepois
        );

    }
);


async function abrirCamera(tipo) {

    cameraDestino =
        tipo;


    if (
        !navigator.mediaDevices ||
        !navigator.mediaDevices.getUserMedia
    ) {

        mostrarMensagem(
            "Seu navegador não suporta acesso à câmera.",
            "erro"
        );

        return;
    }


    try {

        cameraStream =
            await navigator.mediaDevices.getUserMedia({

                video: {

                    facingMode: {
                        ideal: "environment"
                    },

                    width: {
                        ideal: 1920
                    },

                    height: {
                        ideal: 1080
                    }

                },

                audio: false

            });


        cameraVideo.srcObject =
            cameraStream;


        cameraModal.classList.add(
            "aberto"
        );


        await cameraVideo.play();

    }

    catch (erro) {

        console.error(
            "Erro ao abrir câmera:",
            erro
        );


        mostrarMensagem(
            "Não foi possível acessar a câmera. Verifique a permissão do navegador.",
            "erro"
        );

    }
}


function capturarFoto() {

    if (!cameraStream) {
        return;
    }


    const largura =
        cameraVideo.videoWidth;

    const altura =
        cameraVideo.videoHeight;


    if (
        !largura ||
        !altura
    ) {

        mostrarMensagem(
            "A câmera ainda está carregando.",
            "erro"
        );

        return;
    }


    const canvas =
        document.createElement(
            "canvas"
        );


    canvas.width =
        largura;

    canvas.height =
        altura;


    const contexto =
        canvas.getContext("2d");


    contexto.drawImage(
        cameraVideo,
        0,
        0,
        largura,
        altura
    );


    canvas.toBlob(
        function(blob) {

            if (!blob) {

                mostrarMensagem(
                    "Não foi possível capturar a foto.",
                    "erro"
                );

                return;
            }


            const nome =
                `foto-${cameraDestino}-${Date.now()}.jpg`;


            const arquivo =
                new File(
                    [blob],
                    nome,
                    {
                        type: "image/jpeg"
                    }
                );


            const dataTransfer =
                new DataTransfer();


            dataTransfer.items.add(
                arquivo
            );


            if (
                cameraDestino === "antes"
            ) {

                fotoAntes.files =
                    dataTransfer.files;


                processarFoto(
                    fotoAntes,
                    previewAntes,
                    areaAntes,
                    containerAntes
                );

            }


            else {

                fotoDepois.files =
                    dataTransfer.files;


                processarFoto(
                    fotoDepois,
                    previewDepois,
                    areaDepois,
                    containerDepois
                );

            }


            fecharCamera();

        },

        "image/jpeg",

        0.90
    );
}


function fecharCamera() {

    if (cameraStream) {

        cameraStream
            .getTracks()
            .forEach(
                function(track) {

                    track.stop();

                }
            );


        cameraStream =
            null;
    }


    cameraVideo.srcObject =
        null;


    cameraModal.classList.remove(
        "aberto"
    );


    cameraDestino =
        null;
}

cameraModal.addEventListener(
    "click",
    function(event) {

        if (
            event.target === cameraModal
        ) {

            fecharCamera();

        }

    }
);


document.addEventListener(
    "keydown",
    function(event) {

        if (
            event.key === "Escape" &&
            cameraModal.classList.contains("aberto")
        ) {

            fecharCamera();

        }

    }
);


removerAntes.addEventListener(
    "click",
    function() {

        fotoAntes.value =
            "";

        previewAntes.src =
            "";

        areaAntes.classList.remove(
            "tem-foto"
        );

        containerAntes.classList.remove(
            "tem-foto"
        );

        limparMensagem();

    }
);


removerDepois.addEventListener(
    "click",
    function() {

        fotoDepois.value =
            "";

        previewDepois.src =
            "";

        areaDepois.classList.remove(
            "tem-foto"
        );

        containerDepois.classList.remove(
            "tem-foto"
        );

        limparMensagem();

    }
);


observacao.addEventListener(
    "input",
    function() {

        contadorCaracteres.textContent =
            observacao.value.length;

    }
);


btnSalvar.addEventListener(
    "click",
    salvarRegistro
);


async function salvarRegistro() {

   
    const temFotoAntes =
        fotoAntes.files.length > 0;


    const temFotoDepois =
        fotoDepois.files.length > 0;


    if (
        !temFotoAntes ||
        !temFotoDepois
    ) {

        let mensagemErro = "";


        if (
            !temFotoAntes &&
            !temFotoDepois
        ) {

            mensagemErro =
                "Adicione as fotos de antes e depois da limpeza.";

        }

        else if (!temFotoAntes) {

            mensagemErro =
                "Adicione a foto de antes da limpeza.";

        }

        else {

            mensagemErro =
                "Adicione a foto de depois da limpeza.";

        }


        mostrarMensagem(
            mensagemErro,
            "erro"
        );


        return;
    }


    if (
        !window.showDirectoryPicker
    ) {

        mostrarMensagem(
            "Seu navegador não permite salvar diretamente em uma pasta. Use Google Chrome ou Microsoft Edge.",
            "erro"
        );

        return;
    }


    try {

        btnSalvar.disabled =
            true;


        btnSalvar.innerHTML =
            "<span>⏳</span> Salvando...";


        mostrarMensagem(
            "Escolha a Área de Trabalho na próxima janela.",
            "sucesso"
        );

        const pastaDesktop =
            await window.showDirectoryPicker({
                mode: "readwrite"
            });

        const dataNome =
            obterDataNomeArquivo();

        const nomePasta =
            `Registro_Limpeza_${dataNome}_Sala_203`;


        const pastaRegistro =
            await pastaDesktop.getDirectoryHandle(
                nomePasta,
                {
                    create: true
                }
            );

        const arquivoAntes =
            fotoAntes.files[0];


        const destinoAntes =
            await pastaRegistro.getFileHandle(
                "foto_antes.jpg",
                {
                    create: true
                }
            );


        const gravadorAntes =
            await destinoAntes.createWritable();


        await gravadorAntes.write(
            arquivoAntes
        );


        await gravadorAntes.close();

        const arquivoDepois =
            fotoDepois.files[0];


        const destinoDepois =
            await pastaRegistro.getFileHandle(
                "foto_depois.jpg",
                {
                    create: true
                }
            );


        const gravadorDepois =
            await destinoDepois.createWritable();


        await gravadorDepois.write(
            arquivoDepois
        );


        await gravadorDepois.close();

        const textoObservacao =
            observacao.value.trim();

        const conteudoRegistro =

`REGISTRO DE LIMPEZA
========================================

Data: ${dataRegistro.textContent}

Local: Sala 203

========================================

FOTO ANTES:
foto_antes.jpg

FOTO DEPOIS:
foto_depois.jpg

========================================

OBSERVAÇÃO:

${textoObservacao || "Nenhuma observação registrada."}

========================================

Registro realizado pelo sistema.
`;


        const destinoTexto =
            await pastaRegistro.getFileHandle(
                "registro.txt",
                {
                    create: true
                }
            );


        const gravadorTexto =
            await destinoTexto.createWritable();


        await gravadorTexto.write(
            conteudoRegistro
        );


        await gravadorTexto.close();


        mostrarMensagem(
            `Registro salvo com sucesso na pasta "${nomePasta}"!`,
            "sucesso"
        );


    }

    catch (erro) {

        console.error(
            erro
        );


        // Usuário cancelou
        if (
            erro.name === "AbortError"
        ) {

            mostrarMensagem(
                "Salvamento cancelado.",
                "erro"
            );

        }

        else {

            mostrarMensagem(
                "Não foi possível salvar os arquivos. Verifique as permissões da pasta.",
                "erro"
            );

        }

    }

    finally {

        btnSalvar.disabled =
            false;


        btnSalvar.innerHTML =
            "<span>✓</span> Salvar registro";

    }
}

function mostrarMensagem(
    texto,
    tipo
) {

    mensagem.textContent =
        texto;


    mensagem.className =
        "mensagem " + tipo;
}


function limparMensagem() {

    mensagem.textContent =
        "";


    mensagem.className =
        "mensagem";
}
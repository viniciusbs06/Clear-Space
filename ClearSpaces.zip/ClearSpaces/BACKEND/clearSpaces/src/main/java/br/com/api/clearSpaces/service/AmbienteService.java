package br.com.api.clearSpaces.service;

import br.com.api.clearSpaces.dto.AmbienteDTO;
import br.com.api.clearSpaces.entity.Ambiente;
import br.com.api.clearSpaces.repository.AmbienteRepository;
import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AmbienteService {

    private final AmbienteRepository repository;

    public AmbienteService(AmbienteRepository repository) {
        this.repository = repository;
    }

    @Transactional
    public void criar(AmbienteDTO ambienteDTO){
        repository.save(new Ambiente(ambienteDTO.getNome(),
                ambienteDTO.getTipo(),
                ambienteDTO.getLocalizacao(),
                ambienteDTO.getStatusAmbiente()));
    }

    public List<Ambiente> ler(){
        return repository.findAll();
    }

    @Transactional
    public void atualizar(Long id, AmbienteDTO ambienteDTO){
        Ambiente ambienteEncontrado = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Ambiente não encontrado com o ID: " + id));
        ambienteEncontrado.setNome(ambienteDTO.getNome());
        ambienteEncontrado.setTipo(ambienteDTO.getTipo());
        ambienteEncontrado.setLocalizacao(ambienteDTO.getLocalizacao());
        ambienteEncontrado.setStatusAmbiente(ambienteDTO.getStatusAmbiente());
    }

    @Transactional
    public void deletar(Long id){
        repository.deleteById(id);
    }
}

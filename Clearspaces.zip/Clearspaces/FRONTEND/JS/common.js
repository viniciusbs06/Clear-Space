const API_URL = "http://localhost:8080";

function showToast(mensagem, tipo = "success") {
    const container = document.getElementById("toast-container") || criarToastContainer();
    const toast = document.createElement("div");
    toast.className = `toast toast-${tipo}`;
    toast.innerText = mensagem;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

function criarToastContainer() {
    const container = document.createElement("div");
    container.id = "toast-container";
    const appContainer = document.querySelector(".app-container") || document.body;
    appContainer.appendChild(container);
    return container;
}

function getUsuarioLogado() {
    return JSON.parse(localStorage.getItem("SGC_usuario_logado")) || null;
}

function logout() {
    localStorage.removeItem("SGC_usuario_logado");
}

// ===================== SISTEMA DE NOTIFICAÇÕES (local, via localStorage) =====================
// Não há back-end de notificações, então o "banco" delas é o próprio localStorage.
// Funciona entre abas/dispositivos diferentes no MESMO navegador (dá pra simular o
// Operacional recebendo aviso do Professor abrindo as duas telas em abas separadas).

function listarNotificacoes() {
    return JSON.parse(localStorage.getItem("SGC_notificacoes")) || [];
}

function contarNotificacoesNaoLidas() {
    return listarNotificacoes().filter(n => !n.lida).length;
}

// Grava uma nova notificação. Chamada por quem "avisa" (ex: professor.js ao liberar a sala).
function dispararNotificacao(titulo, mensagem, tipo = "info") {
    const notificacoes = listarNotificacoes();

    notificacoes.push({
        id: Date.now(),
        titulo,
        mensagem,
        tipo,
        dataHora: new Date().toISOString(),
        lida: false
    });

    // Mantém só as últimas 50 pra não crescer pra sempre
    const recentes = notificacoes.slice(-50);
    localStorage.setItem("SGC_notificacoes", JSON.stringify(recentes));
}

function marcarNotificacoesComoLidas() {
    const notificacoes = listarNotificacoes().map(n => ({ ...n, lida: true }));
    localStorage.setItem("SGC_notificacoes", JSON.stringify(notificacoes));
}

function limparNotificacoes() {
    localStorage.setItem("SGC_notificacoes", JSON.stringify([]));
}

// Escuta atualizações de notificações em tempo real vindas de outras abas/dispositivos
window.addEventListener("storage", (event) => {
    if (event.key === "SGC_notificacoes" && event.newValue) {
        const lista = JSON.parse(event.newValue);
        if (lista.length === 0) return;

        const ultimaNotificacao = lista[lista.length - 1];

        // Verifica se a notificação acabou de ser adicionada (nos últimos 3 segundos)
        const tempoDecorrido = Date.now() - new Date(ultimaNotificacao.dataHora).getTime();
        if (tempoDecorrido < 3000) {
            showToast(`${ultimaNotificacao.titulo}: ${ultimaNotificacao.mensagem}`, ultimaNotificacao.tipo || "info");

            if ("Notification" in window && Notification.permission === "granted") {
                new Notification(ultimaNotificacao.titulo, {
                    body: ultimaNotificacao.mensagem,
                    icon: "../favicon.ico"
                });
            }
        }

        // Atualiza o badge sempre que houver mudança, mesmo fora da janela de 3s
        if (typeof atualizarBadgeNotificacoes === "function") {
            atualizarBadgeNotificacoes();
        }
    }
});
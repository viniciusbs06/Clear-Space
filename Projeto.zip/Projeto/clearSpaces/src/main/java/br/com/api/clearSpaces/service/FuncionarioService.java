package br.com.api.clearSpaces.service;

import br.com.api.clearSpaces.dto.FuncionarioDTO;
import br.com.api.clearSpaces.entity.Funcionario;
import br.com.api.clearSpaces.entity.Periodo;
import br.com.api.clearSpaces.repository.FuncionarioRepository;
import br.com.api.clearSpaces.repository.PeriodoRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FuncionarioService {
    @Autowired
    private FuncionarioRepository funcionarioRepository;

    @Autowired
    private PeriodoRepository periodoRepository;

    @Transactional
    public void criar(FuncionarioDTO dto){
        Periodo periodoEncontrado = periodoRepository.findById(dto.getPeriodoId())
                .orElseThrow(() -> new RuntimeException("Periodo não encontrado com o ID: " + dto.getPeriodoId()));
        Funcionario novoFuncionario = new Funcionario(dto.getNome(), dto.getMatricula(), dto.getFuncao(),periodoEncontrado);
        funcionarioRepository.save(novoFuncionario);
    }

    public List<Funcionario> ler(){
        return funcionarioRepository.findAll();
    }

    @Transactional
    public void atualizar(Long id, FuncionarioDTO dto) {
        Funcionario funcionarioExistente = funcionarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Funcionário não encontrado com o ID: " + id));

        Periodo novoPeriodo = periodoRepository.findById(dto.getPeriodoId())
                .orElseThrow(() -> new RuntimeException("Período não encontrado com o ID: " + dto.getPeriodoId()));

        funcionarioExistente.setNome(dto.getNome());
        funcionarioExistente.setMatricula(dto.getMatricula());
        funcionarioExistente.setFuncao(dto.getFuncao());
        funcionarioExistente.setPeriodo(novoPeriodo);
    }

    @Transactional
    public void deletar(Long id){
        funcionarioRepository.deleteById(id);
    }
}

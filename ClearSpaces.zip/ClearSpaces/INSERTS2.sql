use clearSpaces;

select * from funcionario;
select * from periodo;
select * from ambiente;

INSERT INTO funcionario (funcao, matricula, nome, periodo_id, cpf, senha) 
VALUES ('gerente', 'FUNC-1234', 'João Silva', 1, '11111111111', 'senha123');
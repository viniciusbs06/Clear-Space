/* ==========================================================================
   CLEAR SPACE - PAINEL DO GERENTE (gerente.html)
   Depende de: common.js
========================================================================== */

let cacheFuncionarios = JSON.parse(localStorage.getItem("SGC_cache_funcionarios")) || [];

document.addEventListener("DOMContentLoaded", async () => {
    await carregarPainelGerente();
    await atualizarCacheFuncionarios();
    renderizarAlertasGestor();
});

async function atualizarCacheFuncionarios() {
    try {
        const res = await fetch(`${API_URL}/funcionarios/listar`);
        if (res.ok) {
            cacheFuncionarios = await res.json();
            localStorage.setItem("SGC_cache_funcionarios", JSON.stringify(cacheFuncionarios));
        }
    } catch (error) {
        console.warn("API offline, usando cache local de funcionários.");
    }
}

async function carregarPainelGerente() {
    let ambientes = JSON.parse(localStorage.getItem("SGC_locais_fallback")) || [];

    try {
        const resAmbientes = await fetch(`${API_URL}/ambientes`);
        if (resAmbientes.ok) {
            ambientes = await resAmbientes.json();
            localStorage.setItem("SGC_locais_fallback", JSON.stringify(ambientes));
        }
    } catch (error) {}

    const limpos = ambientes.filter(a => a.statusAmbiente && a.statusAmbiente.toLowerCase() === 'limpo').length;
    const pendentes = ambientes.filter(a => a.statusAmbiente && (a.statusAmbiente.toLowerCase() === 'pendente' || a.statusAmbiente.toLowerCase() === 'pendente de limpeza')).length;
    const sujos = ambientes.filter(a => a.statusAmbiente && a.statusAmbiente.toLowerCase() === 'sujo').length;

    if (document.querySelector(".stat-item.blue h2")) document.querySelector(".stat-item.blue h2").innerText = limpos;
    if (document.querySelector(".stat-item.yellow h2")) document.querySelector(".stat-item.yellow h2").innerText = pendentes;
    if (document.querySelector(".stat-item.red-alert h2")) document.querySelector(".stat-item.red-alert h2").innerText = sujos;
}

function renderizarAlertasGestor() {
    const container = document.getElementById("painel-alertas-container");
    if (!container) return;

    const ocorrenciasLocais = JSON.parse(localStorage.getItem("SGC_ocorrencias")) || [];
    const pendentes = ocorrenciasLocais.filter(oc => oc.status === "pendente");

    if (pendentes.length === 0) {
        container.innerHTML = `<p class="no-alerts">Nenhuma ocorrência ou solicitação pendente no momento.</p>`;
        return;
    }

    const optionsFuncionarios = cacheFuncionarios.length > 0
        ? cacheFuncionarios.map(f => `<option value="${f.nome}">${f.nome} (${f.funcao ? f.funcao.toUpperCase() : 'ASG'})</option>`).join('')
        : `<option value="Equipe Geral">Equipe Operacional de Plantão</option>`;

    container.innerHTML = pendentes.slice().reverse().map(oc => `
        <div class="gestor-alerta-card border-${oc.gravidade}">
            <div class="msg-header-line">
                <span class="badge-gravidade badge-${oc.gravidade}">${oc.gravidade}</span>
                <span class="msg-time-stamp">${oc.data}</span>
            </div>
            <div class="alerta-meta-info">Enviado por: <strong>${oc.remetente}</strong></div>
            <div class="msg-body-text">"${oc.mensagem}"</div>

            <div class="designar-box">
                <label>Designar colaborador para solucionar:</label>
                <div class="designar-controls">
                    <select id="select-delegar-${oc.id}">
                        <option value="">Escolha quem vai resolver...</option>
                        ${optionsFuncionarios}
                    </select>
                    <button class="btn-designar-acao" onclick="delegarOcorrencia(${oc.id})">Designar</button>
                </div>
            </div>
        </div>
    `).join('');
}

function delegarOcorrencia(idOcorrencia) {
    const select = document.getElementById(`select-delegar-${idOcorrencia}`);

    if (!select || !select.value) {
        showToast("Por favor, selecione um funcionário antes de designar!", "error");
        return;
    }

    const funcionarioEscolhido = select.value;

    let ocorrenciasLocais = JSON.parse(localStorage.getItem("SGC_ocorrencias")) || [];
    ocorrenciasLocais = ocorrenciasLocais.map(oc => {
        if (oc.id === idOcorrencia) {
            return { ...oc, status: "resolvido", encarregado: funcionarioEscolhido };
        }
        return oc;
    });

    localStorage.setItem("SGC_ocorrencias", JSON.stringify(ocorrenciasLocais));
    showToast(`Sucesso! Problema delegado para ${funcionarioEscolhido}.`);

    renderizarAlertasGestor();
}

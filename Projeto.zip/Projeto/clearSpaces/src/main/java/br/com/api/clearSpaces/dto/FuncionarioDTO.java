package br.com.api.clearSpaces.dto;

import br.com.api.clearSpaces.entity.Funcionario.FuncaoEnum;

public class FuncionarioDTO {
    private String nome;
    private String matricula;
    private FuncaoEnum funcao;
    private Long periodoId;

    public FuncionarioDTO(String nome, String matricula, FuncaoEnum funcao, Long periodoId){
        this.nome = nome;
        this.matricula = matricula;
        this.funcao = funcao;
        this.periodoId = periodoId;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public FuncaoEnum getFuncao() {
        return funcao;
    }

    public void setFuncao(FuncaoEnum funcao) {
        this.funcao = funcao;
    }

    public Long getPeriodoId() {
        return periodoId;
    }

    public void setPeriodoId(Long periodoId) {
        this.periodoId = periodoId;
    }
}

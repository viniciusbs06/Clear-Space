
let editandoTarefaId = null;

document.addEventListener("DOMContentLoaded", async () => {
    const editId = localStorage.getItem('editTarefaId');
    if (!editId) return;

    try {
        const res = await fetch(`${API_URL}/tarefas`);
        if (res.ok) {
            const lista = await res.json();
            const tarefa = lista.find(t => t.id == editId);
            if (tarefa) {
                editandoTarefaId = tarefa.id;
                document.getElementById('txt-tarefa-descricao').value = tarefa.descricao || '';
                document.getElementById('sel-tarefa-tipo').value = tarefa.tipoLimpezaEnum || 'completa';
                document.getElementById('sel-tarefa-periodo').value = tarefa.periodo ? tarefa.periodo.id : 1;

                if (tarefa.horarioConclusao) {
                    document.getElementById('dt-tarefa-prazo').value = tarefa.horarioConclusao.substring(0, 16);
                }

                document.querySelector('h1').innerText = "Editar Tarefa";
                const btnSubmit = document.querySelector("button[type='submit']");
                if (btnSubmit) btnSubmit.innerText = "Atualizar Tarefa";
            }
        }
    } catch (err) {
        console.error("Erro ao carregar tarefa para edição:", err);
    }
});

async function salvarTarefa() {
    const descricao = document.getElementById('txt-tarefa-descricao').value.trim();
    const tipoLimpeza = document.getElementById('sel-tarefa-tipo').value;
    const periodoId = document.getElementById('sel-tarefa-periodo').value;
    const prazo = document.getElementById('dt-tarefa-prazo').value;

    if (!descricao) {
        showToast("Descreva a tarefa!", "error");
        return;
    }

    const tarefaDTO = {
        descricao: descricao,
        tipoLimpeza: tipoLimpeza,
        periodoId: Number(periodoId),
        horarioConclusao: prazo ? (prazo + ":00") : null
    };

    const url = editandoTarefaId ? `${API_URL}/tarefas/${editandoTarefaId}` : `${API_URL}/tarefas`;
    const method = editandoTarefaId ? 'PUT' : 'POST';

    try {
        const response = await fetch(url, {
            method: method,
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(tarefaDTO)
        });

        if (response.ok) {
            showToast(editandoTarefaId ? 'Tarefa atualizada com sucesso!' : 'Tarefa cadastrada com sucesso!');
            localStorage.removeItem('editTarefaId');
            window.location.href = 'tarefas-lista.html';
        } else {
            const msgErro = await response.text();
            alert('Erro ao salvar tarefa: ' + (msgErro || 'Verifique os dados enviados.'));
        }
    } catch (error) {
        console.error('Erro de conexão:', error);
        alert('Erro ao conectar com o servidor Java.');
    }
}
package br.com.api.clearSpaces.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "funcionario")

public class Funcionario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nome;
    private String matricula;

    @Enumerated(EnumType.STRING)
    private FuncaoEnum funcao;

    @ManyToOne
    @JoinColumn(name = "periodo_id")
    private Periodo periodo;

    public enum FuncaoEnum{
        banheirista, asg
    }

    protected Funcionario(){}

    public Funcionario(String nome, String matricula, FuncaoEnum funcao, Periodo periodo){
        this.nome = nome;
        this.matricula = matricula;
        this.funcao = funcao;
        this.periodo = periodo;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }

    public FuncaoEnum getFuncao() {
        return funcao;
    }

    public void setFuncao(FuncaoEnum funcao) {
        this.funcao = funcao;
    }

    public Periodo getPeriodo() {
        return periodo;
    }

    public void setPeriodo(Periodo periodo) {
        this.periodo = periodo;
    }
}

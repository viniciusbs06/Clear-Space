create database limpeza;

use limpeza;

create table periodo(
	id int primary key auto_increment,
    periodo enum('manha','tarde','noite') not null
);

create table funcionario(
	id int auto_increment primary key,
	nome varchar(100) not null,
	matricula varchar(20) unique,
	funcao enum('banheirista','ASG') not null,
    periodo_id int,
    foreign key (periodo_id) references periodo(id)
);

create table ambiente(
	id int auto_increment primary key,
	nome varchar(50) not null,
	tipo enum('sala','banheiro','refeitorio') not null,
	localizacao varchar(50),
    status_ambiente enum ('limpo','sujo','pendente')
);

create table tarefa(
	id int auto_increment primary key,
	descricao varchar(100) not null,
	tipo_limpeza enum('completa','manutencao') not null,
	turno_id int,
	status_id int,
	horario_conclusao datetime,

	foreign key (periodo_id) references periodo(id),
	foreign key (status_id) references status(id)
);

create table cronograma(
	id_cronograma int auto_increment,
    id_funcionario int,
    id_ambiente int,
    id_tarefa int,
    dia_semana Enum('segunda','terça','quarta','quinta','sexta'),
    horario_inicio TIME,
    horario_fim TIME,

    foreign key(id_funcionario) references funcionario(id),
    foreign key(id_ambiente) references ambiente(id),
    foreign key(id_tarefa) references tarefa(id)
);

create table atribuicao(
	id int auto_increment primary key,
	usuario_id int,
	tarefa_id int,
	ambiente_id int,
	dia date,
    
	foreign key (usuario_id) references usuario(id),
	foreign key (tarefa_id) references tarefa(id),
	foreign key (ambiente_id) references ambiente(id)
);
package br.com.api.clearSpaces.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "tarefa")

public class Tarefa {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String descricao;

    @Enumerated(EnumType.STRING)
    private TipoLimpezaEnum tipoLimpezaEnum;

    @ManyToOne
    @JoinColumn(name = "periodo_id")
    private Periodo periodo;

    @Column(name = "horario_conclusao")
    private LocalDateTime horarioConclusao;

    public enum TipoLimpezaEnum {
        completa, manutencao
    }

    protected Tarefa() {}

    public Tarefa(String descricao, TipoLimpezaEnum tipoLimpeza, Periodo periodo, LocalDateTime horarioConclusao) {
        this.descricao = descricao;
        this.tipoLimpezaEnum = tipoLimpeza;
        this.periodo = periodo;
        this.horarioConclusao = horarioConclusao;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public TipoLimpezaEnum getTipoLimpezaEnum() {
        return tipoLimpezaEnum;
    }

    public void setTipoLimpezaEnum(TipoLimpezaEnum tipoLimpezaEnum) {
        this.tipoLimpezaEnum = tipoLimpezaEnum;
    }

    public Periodo getPeriodo() {
        return periodo;
    }

    public void setPeriodo(Periodo periodo) {
        this.periodo = periodo;
    }

    public LocalDateTime getHorarioConclusao() {
        return horarioConclusao;
    }

    public void setHorarioConclusao(LocalDateTime horarioConclusao) {
        this.horarioConclusao = horarioConclusao;
    }
}

package br.com.api.clearSpaces.dto;

import java.time.LocalDate;

public class AtribuicaoDTO {
    private Long funcionarioId;
    private Long tarefaId;
    private Long ambienteId;
    private LocalDate dia;

    public AtribuicaoDTO(Long funcionarioId, Long tarefaId, Long ambienteId, LocalDate dia) {
        this.funcionarioId = funcionarioId;
        this.tarefaId = tarefaId;
        this.ambienteId = ambienteId;
        this.dia = dia;
    }

    public LocalDate getDia() {
        return dia;
    }

    public void setDia(LocalDate dia) {
        this.dia = dia;
    }

    public Long getAmbienteId() {
        return ambienteId;
    }

    public void setAmbienteId(Long ambienteId) {
        this.ambienteId = ambienteId;
    }

    public Long getTarefaId() {
        return tarefaId;
    }

    public void setTarefaId(Long tarefaId) {
        this.tarefaId = tarefaId;
    }

    public Long getFuncionarioId() {
        return funcionarioId;
    }

    public void setFuncionarioId(Long funcionarioId) {
        this.funcionarioId = funcionarioId;
    }
}
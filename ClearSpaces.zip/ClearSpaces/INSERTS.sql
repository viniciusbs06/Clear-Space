use clearspaces;

insert into periodo (id, periodo_enum) values (1,'manha');
insert into periodo (id, periodo_enum) values (2,'tarde');
insert into periodo (id, periodo_enum) values (3,'noite');
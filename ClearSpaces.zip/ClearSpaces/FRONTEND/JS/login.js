/* ==========================================================================
   CLEAR SPACE - LOGIN (index.html)
   Depende de: common.js
========================================================================== */

async function fazerLogin(event) {
    if (event) event.preventDefault();

    const identificacao = document.getElementById('login-identificacao').value.trim();
    const senha = document.getElementById('login-senha').value.trim();

    if (!identificacao || !senha) {
        alert('Por favor, preencha o login e a senha!');
        return;
    }

    const loginDTO = {
        cpf: identificacao,
        matricula: identificacao,
        senha: senha
    };

    try {
        const response = await fetch(`${API_URL}/funcionarios`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(loginDTO)
        });

        if (response.ok) {
            const usuario = await response.json(); // Dados do funcionário vindos do Spring Boot

            // Guarda o usuário logado para as outras páginas usarem (ex: identificar quem envia uma ocorrência)
            localStorage.setItem('SGC_usuario_logado', JSON.stringify(usuario));

            alert(`Seja bem-vindo, ${usuario.nome}!`);

            const funcao = (usuario.funcao || '').toUpperCase();

            // Redirecionamento automático por nível de acesso
            if (funcao === 'GERENTE') {
                window.location.href = 'gerente.html';
            } else {
                window.location.href = 'operacional.html';
            }
        } else {
            const erroMsg = await response.text();
            alert(erroMsg || 'Usuário ou senha incorretos.');
        }
    } catch (error) {
        console.error('Erro ao realizar login:', error);
        alert('Erro ao conectar com o servidor Spring Boot.');
    }
}

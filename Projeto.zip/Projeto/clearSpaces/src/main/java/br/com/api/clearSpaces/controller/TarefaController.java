package br.com.api.clearSpaces.controller;

import br.com.api.clearSpaces.dto.TarefaDTO;
import br.com.api.clearSpaces.entity.Tarefa;
import br.com.api.clearSpaces.service.TarefaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tarefas")
@CrossOrigin("*")
public class TarefaController {

    @Autowired
    private TarefaService tarefaService;

    @PostMapping
    public void criar(@RequestBody TarefaDTO dto) {
        tarefaService.salvar(dto);
    }

    @GetMapping
    public List<Tarefa> listar() {
        return tarefaService.listarTodas();
    }

    @PutMapping("/{id}")
    public void atualizar(@PathVariable Long id, @RequestBody TarefaDTO dto) {
        tarefaService.atualizar(id, dto);
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id) {
        tarefaService.deletar(id);
    }
}
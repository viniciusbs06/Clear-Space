package br.com.api.clearSpaces;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClearSpacesApplicationTests {

	@Test
	void contextLoads() {
	}

}

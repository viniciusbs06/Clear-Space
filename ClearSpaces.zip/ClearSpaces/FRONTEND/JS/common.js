/* ==========================================================================
   CLEAR SPACE - COMUM A TODAS AS PÁGINAS
   Inclua este arquivo em TODA página, sempre ANTES do JS específico dela.
========================================================================== */

const API_URL = "http://localhost:8080";

function showToast(mensagem, tipo = "success") {
    const container = document.getElementById("toast-container") || criarToastContainer();
    const toast = document.createElement("div");
    toast.className = `toast toast-${tipo}`;
    toast.innerText = mensagem;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
}

function criarToastContainer() {
    const container = document.createElement("div");
    container.id = "toast-container";
    const appContainer = document.querySelector(".app-container") || document.body;
    appContainer.appendChild(container);
    return container;
}

// Usuário autenticado (salvo pelo login.js em fazerLogin)
function getUsuarioLogado() {
    return JSON.parse(localStorage.getItem("SGC_usuario_logado")) || null;
}

function logout() {
    localStorage.removeItem("SGC_usuario_logado");
}

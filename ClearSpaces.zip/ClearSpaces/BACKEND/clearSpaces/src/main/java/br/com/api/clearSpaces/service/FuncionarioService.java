package br.com.api.clearSpaces.service;

import br.com.api.clearSpaces.dto.FuncionarioDTO;
import br.com.api.clearSpaces.dto.LoginDTO;
import br.com.api.clearSpaces.entity.Funcionario;
import br.com.api.clearSpaces.entity.Periodo;
import br.com.api.clearSpaces.repository.FuncionarioRepository;
import br.com.api.clearSpaces.repository.PeriodoRepository;
import jakarta.servlet.http.HttpSession;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FuncionarioService {
    @Autowired
    private FuncionarioRepository funcionarioRepository;

    @Autowired
    private PeriodoRepository periodoRepository;

    @Transactional
    public void criar(FuncionarioDTO dto){
        Periodo periodoEncontrado = periodoRepository.findById(dto.getPeriodoId())
                .orElseThrow(() -> new RuntimeException("Periodo não encontrado com o ID: " + dto.getPeriodoId()));
        Funcionario novoFuncionario = new Funcionario(dto.getNome(), dto.getCpf(), dto.getSenha(), dto.getFuncao(),periodoEncontrado);
        funcionarioRepository.save(novoFuncionario);
    }

    public List<Funcionario> ler(){
        return funcionarioRepository.findAll();
    }

    @Transactional
    public void atualizar(Long id, FuncionarioDTO dto) {
        Funcionario funcionarioExistente = funcionarioRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Funcionário não encontrado com o ID: " + id));

        Periodo novoPeriodo = periodoRepository.findById(dto.getPeriodoId())
                .orElseThrow(() -> new RuntimeException("Período não encontrado com o ID: " + dto.getPeriodoId()));

        funcionarioExistente.setNome(dto.getNome());
        funcionarioExistente.setCpf(dto.getCpf());
        funcionarioExistente.setSenha(dto.getSenha());
        funcionarioExistente.setFuncao(dto.getFuncao());
        funcionarioExistente.setPeriodo(novoPeriodo);
    }

    @Transactional
    public void deletar(Long id){
        funcionarioRepository.deleteById(id);
    }

    public Optional<Funcionario> acharPorCpf(String cpf){
        return funcionarioRepository.findByCpf(cpf);
    }

    public Optional<Funcionario> acharPorMatricula(String matricula){
        return funcionarioRepository.findByMatricula(matricula);
    }

    public ResponseEntity<String> login(LoginDTO dto, HttpSession session){
        Optional<Funcionario> funcionarioCpfTmp = acharPorCpf(dto.getCpf());
        Optional<Funcionario> funcionarioMatriculaTmp = acharPorMatricula(dto.getMatricula());

        if (funcionarioCpfTmp.isPresent()){
            session.setAttribute("nome", funcionarioCpfTmp.get().getNome());
            session.setAttribute("funcao", funcionarioCpfTmp.get().getFuncao());
            if (dto.getSenha().equals(funcionarioCpfTmp.get().getSenha())){
                return ResponseEntity.ok("Seja bem vindo " + (String) session.getAttribute("nome") + " !");
            }else{
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Senha incorreta");
            }
        }else if (funcionarioMatriculaTmp.isPresent()){
            session.setAttribute("nome", funcionarioMatriculaTmp.get().getNome());
            session.setAttribute("funcao", funcionarioMatriculaTmp.get().getFuncao());
            if (dto.getSenha().equals(funcionarioMatriculaTmp.get().getSenha())){
                return ResponseEntity.ok("Seja bem vindo " + (String) session.getAttribute("nome") + " !");
            }else{
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Senha incorreta");
            }
        }else{
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Funcionario inexistente");
        }
    }

    public ResponseEntity<String> logout(HttpSession session) {
        session.invalidate();
        return ResponseEntity.status(HttpStatus.GATEWAY_TIMEOUT).body("Saiu com sucesso");
    }

    public ResponseEntity<String> funcionarioLogado(HttpSession session) {
        String nome = (String) session.getAttribute("nome");
        if (nome != null){
            return ResponseEntity.ok("Funcionário logado: " + nome);
        }else{
            return ResponseEntity.ok("Nenhum usuario logado! ");
        }
    }
}

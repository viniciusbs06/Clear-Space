document.addEventListener("DOMContentLoaded", () => {
    carregarMinhasTarefasHoje();
});

function getDiaSemanaAtual() {
   
    const dias = ["domingo", "segunda", "terça", "quarta", "quinta", "sexta", "sábado"];
    return dias[new Date().getDay()];
}

async function carregarMinhasTarefasHoje() {
    const container = document.getElementById("lista-minhas-tarefas");
    if (!container) return;

    const usuario = getUsuarioLogado();
    if (!usuario) {
        container.innerHTML = `<p class="no-alerts">Sessão expirada. Faça login novamente.</p>`;
        return;
    }

    const diaHoje = getDiaSemanaAtual();

    if (diaHoje === "domingo" || diaHoje === "sábado") {
        container.innerHTML = `<p class="no-alerts">Sem escala definida para hoje (${diaHoje}).</p>`;
        return;
    }

    let cronogramas = JSON.parse(localStorage.getItem("SGC_escalas_fallback")) || [];

    try {
        const res = await fetch(`${API_URL}/cronogramas`);
        if (res.ok) {
            cronogramas = await res.json();
            localStorage.setItem("SGC_escalas_fallback", JSON.stringify(cronogramas));
        }
    } catch (error) {
        console.warn("API offline, usando cache local de cronogramas.");
    }

    const minhasTarefas = cronogramas.filter(c =>
        c.funcionario &&
        c.funcionario.id === usuario.id &&
        c.diaSemana &&
        c.diaSemana.trim().toLowerCase() === diaHoje
    );

    if (minhasTarefas.length === 0) {
        container.innerHTML = `<p class="no-alerts">Nenhuma tarefa atribuída a você hoje.</p>`;
        return;
    }

    container.innerHTML = minhasTarefas.map((cron, index) => `
        <div class="escala-slot" data-index="${index}" style="cursor: pointer;">
            <div>${cron.ambiente ? cron.ambiente.nome : "Ambiente Geral"}</div>
            <div>Tarefa: ${cron.tarefa ? cron.tarefa.descricao : "Limpeza Geral"}</div>
            <div>Responsável: Você</div>
            <div style="margin-top: 8px; color: var(--azul-claro); font-weight: 700;">
                ⏰ Horário: ${cron.horarioInicio ? cron.horarioInicio.substring(0, 5) : "--:--"}h às ${cron.horarioFim ? cron.horarioFim.substring(0, 5) : "--:--"}h
            </div>
        </div>
    `).join('');

    container.querySelectorAll(".escala-slot").forEach(el => {
        el.addEventListener("click", () => {
            const cron = minhasTarefas[Number(el.dataset.index)];
            abrirChecklist(cron);
        });
    });
}

function abrirChecklist(cron) {
    if (!cron.tarefa || !cron.tarefa.id) {
        showToast("Esta escala não possui uma tarefa vinculada.", "error");
        return;
    }

    const dadosTarefa = {
        cronogramaId: cron.idCronograma,
        tarefaId: cron.tarefa.id,
        tarefaDescricao: cron.tarefa.descricao,
        ambienteNome: cron.ambiente ? cron.ambiente.nome : "Ambiente"
    };

    localStorage.setItem("SGC_tarefa_atual", JSON.stringify(dadosTarefa));
    window.location.href = "func-checklist.html";
}
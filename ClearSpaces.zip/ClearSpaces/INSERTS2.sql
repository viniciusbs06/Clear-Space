use clearSpaces;

select * from funcionario;

INSERT INTO funcionario (funcao, matricula, nome, periodo_id, cpf, senha) 
VALUES ('asg', 'ASG12345', 'João Silva', 1, '12345678900', 'senha123');
let diaSelecionado = "segunda";

document.addEventListener("DOMContentLoaded", () => {
    configurarNavegacaoSemana();
    carregarListaEscalas();
});

function configurarNavegacaoSemana() {
    document.querySelectorAll(".week-nav span").forEach(btn => {
        btn.addEventListener("click", (e) => {
            document.querySelectorAll(".week-nav span").forEach(b => {
                b.classList.remove("active");
                b.setAttribute("aria-selected", "false");
            });
            e.target.classList.add("active");
            e.target.setAttribute("aria-selected", "true");

            const textoDia = e.target.innerText.toLowerCase();
            if (textoDia.includes("seg")) diaSelecionado = "segunda";
            else if (textoDia.includes("ter")) diaSelecionado = "terça";
            else if (textoDia.includes("qua")) diaSelecionado = "quarta";
            else if (textoDia.includes("qui")) diaSelecionado = "quinta";
            else if (textoDia.includes("sex")) diaSelecionado = "sexta";
            else if (textoDia.includes("sab") || textoDia.includes("sáb")) diaSelecionado = "sábado";
            else if (textoDia.includes("dom")) diaSelecionado = "domingo";

            carregarListaEscalas();
        });
    });
}

async function carregarListaEscalas() {
    const container = document.getElementById("lista-escalas-container");
    if (!container) return;

    let atribuicoes = JSON.parse(localStorage.getItem("SGC_escalas_fallback")) || [];

    try {
        const res = await fetch(`${API_URL}/atribuicoes`);
        if (res.ok) {
            const dadosApi = await res.json();
            // Confia sempre na resposta da API quando ela responde OK,
            // mesmo que a lista venha vazia (ex: depois de deletar o último item)
            atribuicoes = dadosApi || [];
            localStorage.setItem("SGC_escalas_fallback", JSON.stringify(atribuicoes));
        }
    } catch (error) {
        console.error("Erro ao carregar escala da API:", error);
    }

    const diaAba = diaSelecionado.substring(0, 3).toLowerCase();
    const escalasDoDia = atribuicoes.filter(c => c.diaSemana && c.diaSemana.toLowerCase().includes(diaAba));

    if (escalasDoDia.length === 0) {
        container.innerHTML = `
            <a href="escala-form.html" onclick="limparFormEscala()" style="cursor:pointer; text-decoration:none; display:block; padding:20px; text-align:center; border: 2px dashed #ccc; border-radius: 8px; color: #666; margin-top: 15px;">
                + Nenhuma escala para esta ${diaSelecionado}. Clique para adicionar.
            </a>`;
        return;
    }

    container.innerHTML = escalasDoDia.map(cron => `
        <div class="escala-slot" style="border: 1px solid #ccc; padding: 15px; margin-top: 15px; border-radius: 8px; background: #fff; box-shadow: 0 2px 4px rgba(0,0,0,0.05);">
            <div style="font-weight: bold; color: #1a56db; font-size: 16px; margin-bottom: 5px;">📍 ${cron.ambiente ? cron.ambiente.nome : 'Ambiente Geral'}</div>
            <div style="margin-bottom: 3px;"><strong>Tarefa:</strong> ${cron.tarefa ? cron.tarefa.descricao : 'Limpeza Geral'}</div>
            <div style="margin-bottom: 3px;"><strong>Responsável:</strong> ${cron.funcionario ? cron.funcionario.nome : 'Sem Colaborador'}</div>
            <div style="margin-bottom: 8px; color: #555;">⏰ <strong>Horário:</strong> ${cron.horarioInicio ? cron.horarioInicio.substring(0,5) : '00:00'}h às ${cron.horarioFim ? cron.horarioFim.substring(0,5) : '00:00'}h</div>
            <div class="crud-actions" style="margin-top:10px; display:flex; justify-content:flex-end; gap: 15px; font-size: 18px; cursor: pointer;">
                <span onclick="editarEscala('${cron.id}')" title="Editar">✏️</span>
                <span onclick="deletarEscala('${cron.id}')" title="Excluir">🗑️</span>
            </div>
        </div>
    `).join('');
}

function limparFormEscala() {
    localStorage.removeItem('editEscalaId');
}

function editarEscala(id) {
    localStorage.setItem('editEscalaId', id);
    window.location.href = 'escala-form.html';
}

async function deletarEscala(id) {
    if (!confirm("Remover este horário da grade?")) return;

    try {
        const res = await fetch(`${API_URL}/atribuicoes/${id}`, { method: "DELETE" });
        if (res.ok) {
            if (typeof showToast === "function") showToast("Escala excluída.");
            carregarListaEscalas();
            return;
        }
    } catch (error) {
        console.error("Erro ao deletar escala via API:", error);
    }

    let bancoEscalas = JSON.parse(localStorage.getItem("SGC_escalas_fallback")) || [];
    bancoEscalas = bancoEscalas.filter(e => String(e.id) !== String(id));
    localStorage.setItem("SGC_escalas_fallback", JSON.stringify(bancoEscalas));
    if (typeof showToast === "function") showToast("Removido localmente!");
    carregarListaEscalas();
}
const themeToggle = document.getElementById("themeToggle");
const themeIcon = document.querySelector(".theme-icon");
const temaSalvo = localStorage.getItem("tema");

if (temaSalvo === "escuro") {
    document.body.classList.add("dark-mode");
    themeIcon.textContent = "☾";
    themeToggle.setAttribute(
        "aria-label",
        "Ativar tema claro"
    );
} else {
    themeIcon.textContent = "☀";
    themeToggle.setAttribute(
        "aria-label",
        "Ativar tema escuro"
    );
}

themeToggle.addEventListener("click", function () {
    document.body.classList.toggle("dark-mode");
    if (document.body.classList.contains("dark-mode")) {
        themeIcon.textContent = "☾";
        themeToggle.setAttribute(
            "aria-label",
            "Ativar tema claro"
        );
        localStorage.setItem("tema", "escuro");
    } else {
        themeIcon.textContent = "☀";
        themeToggle.setAttribute(
            "aria-label",
            "Ativar tema escuro"
        );
        localStorage.setItem("tema", "claro");
    }

});

const botao = document.getElementById("btnMensagem");
if (botao) {
    botao.addEventListener("click", function () {
        alert(
            "Obrigado pelo interesse no projeto Clear Space! " +
            "Nossa plataforma foi pensada para tornar a rotina de limpeza mais simples, rápida e organizada."
        );

    });

}